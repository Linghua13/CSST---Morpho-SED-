# -*- coding: utf-8 -*-
import numpy as np
import matplotlib.pyplot as plt
import os
import datetime
from matplotlib.colors import LogNorm
import pandas as pd


#用新的criteria分类galaxy/star/qso

starttime = datetime.datetime.now()

df=pd.read_csv('/media/xie/D/job/CSST/mock_catalog1/in+out/z_free_slim.csv') #,不要加skiprows=1，否则会列名不见了，最后面保存的数据没有了列名！ 
df.drop(df.index[0], inplace=True)#删掉第一行，为了跟之前的结果一致，之前的数据pd.read_csv加了skiprows=1，数据少了第一行，现在前面读数据时不跳过第一行，读出来之后就要补上删去第一行的操作。

print (df.shape)  #print 出（行，列）
df1=np.array(df)  #把它转换为numpy数据格式。
print ('\n')

#删除红移小于0的,负model的,负质量的rows:
photoz_sim=df1[:,15]
MASS_BEST=df1[:,44]
MOD_BEST=df1[:,28] 
MOD_QSO=df1[:,32] 
MOD_STAR=df1[:,33] 
SED_TYPE=df1[:,47]
delete_rows1=[]
delete_rows2=[]
delete_rows3=[]
delete_rows4=[]
delete_rows5=[]
delete_rows6=[]
for i in range(len(photoz_sim)):
    if photoz_sim[i]<0:
        delete_rows1.append(i)
    if '-999.0' in str(MOD_BEST[i]) and '-999.0' in str(MOD_QSO[i]) and '-999.0' in str(MOD_STAR[i]):
        delete_rows2.append(i)

#or '-999.0' in str(SED_TYPE[i]):
        #delete_rows2.append(i)
    if MASS_BEST[i]<0:
        delete_rows3.append(i)
    if '-999.0' in str(MASS_BEST[i]):
        delete_rows4.append(i)
    if '-999.0' in str(MOD_BEST[i]):
        delete_rows5.append(i)
    if '-999.0' in str(SED_TYPE[i]):
        delete_rows6.append(i)
delete_rows=list( set(delete_rows1) | set(delete_rows2) )
df1=np.delete(df1,delete_rows,axis=0)
print ('delete rows: %s'%(len(delete_rows))) #0
'''
print ('photoz_sim<0: %s'%(len(delete_rows1)))
print ('MOD_BEST & MOD_QSO & MOD_STAR -999.0: %s'%(len(delete_rows2)))
print ('MASS_BEST <0: %s'%(len(delete_rows3)))
print ('MASS_BEST -999.0: %s'%(len(delete_rows4)))
print ('MOD_BEST -999.0: %s'%(len(delete_rows5)))
print ('SED_TYPE -999.0: %s'%(len(delete_rows6)))
print (df1.shape)
'''
print ('\n')



#print 'len(mass):',len(mass)
#SeqNr=df1[:,0]
MAG_AUTO_nuv=df1[:,1]
MAGERR_AUTO_nuv=df1[:,2]
MAG_AUTO_u=df1[:,3]
MAGERR_AUTO_u=df1[:,4]
MAG_AUTO_g=df1[:,5]
MAGERR_AUTO_g=df1[:,6]
MAG_AUTO_r=df1[:,7]
MAGERR_AUTO_r=df1[:,8]
MAG_AUTO_i=df1[:,9]
MAGERR_AUTO_i=df1[:,10]
MAG_AUTO_z=df1[:,11]
MAGERR_AUTO_z=df1[:,12]
MAG_AUTO_y=df1[:,13]
MAGERR_AUTO_y=df1[:,14]
photoz_sim=df1[:,15]
Type=df1[:,17]
Ra=df1[:,18]
Dec=df1[:,19]
CLASS_STAR_nuv=df1[:,20]
CLASS_STAR_u=df1[:,21]
CLASS_STAR_g=df1[:,22]
CLASS_STAR_r=df1[:,23]
CLASS_STAR_i=df1[:,24]
CLASS_STAR_z=df1[:,25]
CLASS_STAR_y=df1[:,26]
CHI_BEST=df1[:,27]
MOD_BEST=df1[:,28]
#MOD_BEST=df1[:,20]
#EBV_BEST=df1[:,21]
#NBAND_USED=df1[:,22]
CHI_QSO=df1[:,31]
MOD_QSO=df1[:,32]
MOD_STAR=df1[:,33]
CHI_STAR=df1[:,34]
#AGE_BEST=df1[:,39]/1e9
MASS_BEST=df1[:,44]
#SFR_BEST=df1[:,41]
#SSFR_BEST=df1[:,42]
SED_TYPE=df1[:,47]

MAG_AUTO_nuv[MAG_AUTO_nuv==-999.0]=44.0
MAG_AUTO_u[MAG_AUTO_u==-999.0]=44.0
MAG_AUTO_g[MAG_AUTO_g==-999.0]=44.0
MAG_AUTO_r[MAG_AUTO_r==-999.0]=44.0
MAG_AUTO_i[MAG_AUTO_i==-999.0]=44.0
MAG_AUTO_z[MAG_AUTO_z==-999.0]=44.0
MAG_AUTO_y[MAG_AUTO_y==-999.0]=44.0

g_z=MAG_AUTO_g-MAG_AUTO_z
g_y=MAG_AUTO_g-MAG_AUTO_y
z_y=MAG_AUTO_z-MAG_AUTO_y
u_r=MAG_AUTO_u-MAG_AUTO_r
g_r=MAG_AUTO_g-MAG_AUTO_r  
nuv_r=MAG_AUTO_nuv-MAG_AUTO_r 
nuv_u=MAG_AUTO_nuv-MAG_AUTO_u
nuv_g=MAG_AUTO_nuv-MAG_AUTO_g  


z_rows0=[]
z_rows1=[]
z_rows2=[]
z_rows3=[]
for i in range(len(photoz_sim)):
    if photoz_sim[i]==0:
        z_rows0.append(i)
    if photoz_sim[i]>0 and photoz_sim[i]<=1:
        z_rows1.append(i)
    if photoz_sim[i]>1 and photoz_sim[i]<=2:
        z_rows2.append(i)
    if photoz_sim[i]>2:
        z_rows3.append(i)
'''
print ('photoz_sim distribution:')
print ('z=0: %s'%(len(z_rows0)))
print ('0<z<1: %s'%(len(z_rows1)))
print ('0<z<1: %s'%(len(z_rows2)))
print ('z>2: %s'%(len(z_rows3)))
print ('max(z): %s'%(max(photoz_sim)))
print ('\n')
'''

'''
num_bins = 50  
n, bins, patches =plt.hist(photoz_sim, num_bins,density=1, facecolor='blue', alpha=0.5)  
plt.xlabel('photoz_sim')
plt.ylabel('number')
#plt.xlim(5,14)
plt.title(str(len(MASS_BEST))+' galaxies of CSST')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/photoz_sim.pdf')
plt.close('all')

num_bins = 50  
n, bins, patches =plt.hist(MAG_AUTO_nuv, num_bins,density=1, facecolor='blue', alpha=0.5)  
plt.xlabel('MAG_AUTO_nuv')
plt.ylabel('number')
plt.xlim(15,30)
plt.title(str(len(MASS_BEST))+' galaxies of CSST')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/MAG_AUTO_nuv.pdf')
plt.close('all')

num_bins = 50  
n, bins, patches =plt.hist(MAG_AUTO_u, num_bins,density=1, facecolor='blue', alpha=0.5)  
plt.xlabel('MAG_AUTO_u')
plt.ylabel('number')
plt.xlim(15,30)
plt.title(str(len(MASS_BEST))+' galaxies of CSST')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/MAG_AUTO_u.pdf')
plt.close('all')

num_bins = 50  
n, bins, patches =plt.hist(MAG_AUTO_g, num_bins,density=1, facecolor='blue', alpha=0.5)  
plt.xlabel('MAG_AUTO_g')
plt.ylabel('number')
plt.xlim(15,30)
plt.title(str(len(MASS_BEST))+' galaxies of CSST')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/MAG_AUTO_g.pdf')
plt.close('all')

num_bins = 50  
n, bins, patches =plt.hist(MAG_AUTO_r, num_bins,density=1, facecolor='blue', alpha=0.5)  
plt.xlabel('MAG_AUTO_r')
plt.ylabel('number')
plt.xlim(15,30)
plt.title(str(len(MASS_BEST))+' galaxies of CSST')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/MAG_AUTO_r.pdf')
plt.close('all')

num_bins = 50  
n, bins, patches =plt.hist(MAG_AUTO_i, num_bins,density=1, facecolor='blue', alpha=0.5)  
plt.xlabel('MAG_AUTO_i')
plt.ylabel('number')
plt.xlim(15,30)
plt.title(str(len(MASS_BEST))+' galaxies of CSST')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/MAG_AUTO_i.pdf')
plt.close('all')

num_bins = 50  
n, bins, patches =plt.hist(MAG_AUTO_z, num_bins,density=1, facecolor='blue', alpha=0.5)  
plt.xlabel('MAG_AUTO_z')
plt.ylabel('number')
plt.xlim(15,30)
plt.title(str(len(MASS_BEST))+' galaxies of CSST')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/MAG_AUTO_z.pdf')
plt.close('all')

num_bins = 50  
n, bins, patches =plt.hist(MAG_AUTO_y, num_bins,density=1, facecolor='blue', alpha=0.5)  
plt.xlabel('MAG_AUTO_y')
plt.ylabel('number')
plt.xlim(15,30)
plt.title(str(len(MASS_BEST))+' galaxies of CSST')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/MAG_AUTO_y.pdf')
plt.close('all')
'''


#记下总的galaxy,star,qso分别所在的行。
QSO_rows=[]
QSO_rows1=[]
QSO_rows2=[]
STAR_rows1=[]
STAR_rows2=[]
rows_all=[]
largechi_galaxy_rows=[]
largechi_galaxy_rows2=[]
largechi_star_rows=[]
extend_rows=[]
pointlike_rows=[]
region_rows_galaxy=[]
region_rows_qso=[]
#chi_rows_6=[]
#chi_rows_3=[]
rows_galaxy_true=[]#true type rows
rows_star_true=[]
rows_qso_true=[]
GAL_rows1=[]
GAL_rows2=[]
galaxy_good_fitting_rows=[]
star_good_fitting_rows=[]
qso_good_fitting_rows=[]
letter_chi_star_rows=[]
letter_chi_qso_rows=[]
small_mass_rows=[]
color_cut_qso=[]
extend_star1=[]
extend_star2=[]
extend_qso=[]
for i in range(len(CHI_BEST)):
    #if (CHI_QSO[i]/6.0)<(CHI_STAR[i]/7.0) and (CHI_QSO[i]/6.0)<(CHI_BEST[i]/5.0) and Type[i]>0 and (CHI_QSO[i]/6.0)<6:
        #chi_rows_6.append(i)
    #if (CHI_QSO[i]/6.0)<(CHI_STAR[i]/7.0) and (CHI_QSO[i]/6.0)<(CHI_BEST[i]/5.0) and Type[i]>0 and (CHI_QSO[i]/6.0)<3:
        #chi_rows_3.append(i)
    if Type[i]==0:
        rows_galaxy_true.append(i)
    if Type[i]==1:
        rows_star_true.append(i)
    if Type[i]==2:
        rows_qso_true.append(i)
    if CLASS_STAR_r[i]<0.94:
        extend_rows.append(i)
    if CLASS_STAR_r[i]>=0.94:
        pointlike_rows.append(i)
    if MASS_BEST[i]>0 and MOD_BEST[i]>0 and SED_TYPE[i]>0:
        galaxy_good_fitting_rows.append(i)
    if MOD_STAR[i]>0:
        star_good_fitting_rows.append(i)
    if MOD_QSO[i]>0:
        qso_good_fitting_rows.append(i)
    if MASS_BEST[i]<-30:
        small_mass_rows.append(i)
    if MASS_BEST[i]<7 and CLASS_STAR_r[i]>0.8:
        extend_star1.append(i)
    if MASS_BEST[i]<4.6 and CLASS_STAR_r[i]>0.1 and CLASS_STAR_r[i]<0.8:
        extend_star2.append(i)
    if MASS_BEST[i]>=7 and CLASS_STAR_r[i]>0.85:
        extend_qso.append(i)




    rows_all.append(i)

    #largechi rows
    if (CHI_BEST[i]/5.0)>30: #and J_K[i]<0.2
        largechi_galaxy_rows.append(i)
    if (CHI_BEST[i]/5.0)>600: #and J_K[i]<0.2
        largechi_galaxy_rows2.append(i)

    if (CHI_STAR[i]/7.0)>100: #and J_K[i]<0.2
        largechi_star_rows.append(i)
    if (CHI_STAR[i]/7.0)<24: #and J_K[i]<0.2
        letter_chi_star_rows.append(i)
    if (CHI_QSO[i]/6.0)<5: 
        letter_chi_qso_rows.append(i)
    if MAG_AUTO_g[i]<18: # and g_z[i]
        color_cut_qso.append(i)



    if (CHI_STAR[i]/7.0)<(CHI_BEST[i]/5.0) and CLASS_STAR_r[i]>=0.94: #去star
        STAR_rows1.append(i)
    if (CHI_STAR[i]/7.0)<(CHI_QSO[i]/6.0) and CLASS_STAR_r[i]>=0.94: #去star
        STAR_rows2.append(i)


    if (CHI_QSO[i]/6.0)<(CHI_BEST[i]/5.0) and CLASS_STAR_r[i]>=0.94: #去qso
        QSO_rows1.append(i)
    if (CHI_QSO[i]/6.0)<(CHI_STAR[i]/7.0) and CLASS_STAR_r[i]>=0.94:  #去qso
        QSO_rows2.append(i)


    if (CHI_BEST[i]/5.0)<(CHI_STAR[i]/7.0) and CLASS_STAR_r[i]<0.94: #galaxy1
        GAL_rows1.append(i)
    if (CHI_BEST[i]/5.0)<(CHI_QSO[i]/6.0) and CLASS_STAR_r[i]<0.94: #galaxy2
        GAL_rows2.append(i)
#print ('QSO_rows1: %s'%(len(QSO_rows1)))#2802
rows_rest1=list(set(rows_all)-set(STAR_rows1))  #去star
rows_rest2=list(set(rows_rest1)-set(STAR_rows2))  #去star

QSO_rows=list((set(QSO_rows1)|set(QSO_rows2)) & set(rows_rest2))  #qso,&优先级大于|

rows_rest3=list(set(rows_rest2)-set(QSO_rows))  #去qso 
#print ('rows_rest3: %s'%(len(rows_rest3)))  #20330
#print ('extend_rows: %s'%(len(extend_rows)))  #20330
#GAL_rows=list(set(rows_rest3)&set(extend_rows)-set(small_mass_rows)) 
#print ('small_mass_rows: %s'%(len(small_mass_rows))) #0
GAL_rows=list(set(rows_rest3)&set(extend_rows)) 
#GAL_rows=list(set(rows_rest3)&set(extend_rows)-set(z_rows0))
#GAL_rows=list((set(GAL_rows1)|set(GAL_rows2))&set(rows_rest3)) #galaxy,&优先级大于|

rows_rest4=list(set(rows_rest3)-set(GAL_rows))
#print ('rows_rest4: %s'%(len(rows_rest4)))#0,也就是说，所有rows_rest3都是extend。

'''
#由于rows_rest4=STAR_rows3，所以这一步没什么用，可去掉。或者在criteria说明里不写这一步:
#================start line==================================
#QSO_rows3=list(set(rows_rest3)-set(GAL_rows))
#QSO_rows=list(set(QSO_rows)|set(QSO_rows3))  #qso
STAR_rows3=list(set(rows_rest4)&set(letter_chi_star_rows)) #&set(letter_chi_star_rows)
QSO_rows3=list(set(rows_rest4)-set(STAR_rows3))

QSO_rows=list(set(QSO_rows)|set(QSO_rows3))
#QSO_rows0=list(set(QSO_rows)|set(QSO_rows3))
#QSO_rows=list(set(QSO_rows0)-set(z_rows0))
#STAR_rows4=list(set(QSO_rows0)-set(QSO_rows))




print ('STAR_rows3: %s'%(len(STAR_rows3))) #0
print ('QSO_rows3: %s'%(len(QSO_rows3)))  #3946
print ('letter_chi_star_rows: %s'%(len(letter_chi_star_rows)))
print ('letter_chi_qso_rows: %s'%(len(letter_chi_qso_rows)))

STAR_rows=list(set(STAR_rows1) | set(STAR_rows2) | set(STAR_rows3))
#STAR_rows=list(set(STAR_rows1) | set(STAR_rows2) | set(STAR_rows3) | set(STAR_rows4))
#================end line==================================
'''
STAR_rows=list(set(STAR_rows1) | set(STAR_rows2) | set(rows_rest4))


#加上mass_cut_star和mass_cut_qso:
extend_star=list(set(GAL_rows)&(set(extend_star1)|set(extend_star2)))
extend_qso=list(set(GAL_rows)&set(extend_qso))
GAL_rows=list(set(GAL_rows)-set(extend_star)-set(extend_qso))
STAR_rows=list(set(STAR_rows) | set(extend_star))
QSO_rows=list(set(QSO_rows) | set(extend_qso))
print ('extend_star1: %s'%(len(extend_star1)))
print ('extend_star2: %s'%(len(extend_star2)))
print ('extend_star: %s'%(len(extend_star)))
print ('extend_qso: %s'%(len(extend_qso)))


#加上qso的color cut:
color_cut_qso=list(set(QSO_rows)&set(color_cut_qso))
QSO_rows=list(set(QSO_rows)-set(color_cut_qso))
STAR_rows=list(set(STAR_rows)|set(color_cut_qso))



#match上的共同rows
galaxy_match_rows=list(set(GAL_rows) & set(rows_galaxy_true))
star_match_rows=list(set(STAR_rows) & set(rows_star_true))
qso_match_rows=list(set(QSO_rows) & set(rows_qso_true))


#没match上的 true type rows
galaxy_notmatch_true=list(set(rows_galaxy_true)-set(GAL_rows))
star_notmatch_true=list(set(rows_star_true)-set(STAR_rows))
qso_notmatch_true=list(set(rows_qso_true)-set(QSO_rows))

#没match上的 lephare rows
galaxy_notmatch_lephare=list(set(GAL_rows)-set(rows_galaxy_true))
star_notmatch_lephare=list(set(STAR_rows)-set(rows_star_true))
qso_notmatch_lephare=list(set(QSO_rows)-set(rows_qso_true))


#missclassify:
galaxy_to_star=list(set(galaxy_notmatch_true)&set(STAR_rows))
galaxy_to_qso=list(set(galaxy_notmatch_true)&set(QSO_rows))
star_to_galaxy=list(set(star_notmatch_true)&set(GAL_rows))
star_to_qso=list(set(star_notmatch_true)&set(QSO_rows))
qso_to_galaxy=list(set(qso_notmatch_true)&set(GAL_rows))
qso_to_star=list(set(qso_notmatch_true)&set(STAR_rows))


#z_rows0:
z_rows0_galaxy_lephare=list(set(z_rows0)&set(GAL_rows))
z_rows0_star_lephare=list(set(z_rows0)&set(STAR_rows))
z_rows0_qso_lephare=list(set(z_rows0)&set(QSO_rows))

z_rows0_galaxy_true=list(set(z_rows0)&set(rows_galaxy_true))
z_rows0_star_true=list(set(z_rows0)&set(rows_star_true))
z_rows0_qso_true=list(set(z_rows0)&set(rows_qso_true))

'''
print ('\n')
print ('z=0 distributon:')
print ('lephare:')
print ('galaxy: %s'%(len(z_rows0_galaxy_lephare)))
print ('star: %s'%(len(z_rows0_star_lephare)))
print ('qso: %s'%(len(z_rows0_qso_lephare)))
print ('true type:')
print ('galaxy: %s'%(len(z_rows0_galaxy_true)))
print ('star: %s'%(len(z_rows0_star_true)))
print ('qso: %s'%(len(z_rows0_qso_true)))
print ('\n')

print ('CLASS_STAR_r<0.94: %s'%(len(extend_rows)))
print ('\n')
'''
#print ('galaxy_good_fitting_rows: %s'%(len(galaxy_good_fitting_rows))) #17924
#print ('star_good_fitting_rows: %s'%(len(star_good_fitting_rows))) #23588
#print ('qso_good_fitting_rows: %s'%(len(qso_good_fitting_rows)))  #23588
#print ('\n')

print ('total: %s'%len(CHI_BEST))
print ('lephare:')
print ('GAL_rows: %s'%(len(GAL_rows)))
print ('STAR_rows: %s'%(len(STAR_rows)))
print ('QSO_rows: %s'%(len(QSO_rows)))
print ('\n')

#print ('\n')
print ('true type:')
print ('galaxy: %s'%(len(rows_galaxy_true)))
print ('star: %s'%(len(rows_star_true)))
print ('qso: %s'%(len(rows_qso_true)))
print ('\n')

print ('match:')
print ('galaxy: %s'%(len(galaxy_match_rows)))
print ('star: %s'%(len(star_match_rows)))
print ('qso: %s'%(len(qso_match_rows)))
print ('\n')

print ('missclassify:')
print ('galaxy_to_star: %s'%(len(galaxy_to_star)))
print ('galaxy_to_qso: %s'%(len(galaxy_to_qso)))
print ('star_to_galaxy: %s'%(len(star_to_galaxy)))
print ('star_to_qso: %s'%(len(star_to_qso)))
print ('qso_to_galaxy: %s'%(len(qso_to_galaxy)))
print ('qso_to_star: %s'%(len(qso_to_star)))
print ('\n')



#新的存数据方法:
starttime = datetime.datetime.now()
print ('\n')

type_xie=np.zeros([len(CHI_BEST)],dtype=int)
type_xie[GAL_rows]=0
type_xie[STAR_rows]=1
type_xie[QSO_rows]=2
print ('len(type_xie):%s'%(len(type_xie)))

#df['mass_correct']=mass_correct
#df['metallicity']=metallicity
#df['tau']=tau
df['type_xie']=type_xie

print (df.shape)



#存csv:
df.to_csv('D:\job\CSST\mock_catalog1\catalog_lephare/z_free.csv',index=False)#header=0表示不保留列名，index=False表示不保留行索引，mode='a'表示附加方式写入，文件原有内容不会被清除

endtime = datetime.datetime.now()
usetime=endtime - starttime
starttime = datetime.datetime.now()
print ('csv save Done')
print ('time use: %s'%(usetime))
print ('\n')




#存fits:
columns=df.columns.values#列名数组，元素类型数据是字符串
print (len(columns))
data_format=[]
dtypes = [str(df.dtypes[i]) for i in range(len(columns))]
for i in range(len(dtypes)):
    if dtypes[i]=='int64':  #整数
        data_format.append('K')  
    if dtypes[i]=='object':     #字符串
        data_format.append('A16')
    if dtypes[i]=='float64':    #双精度浮点型
        data_format.append('D')


cols=[]
for i in range(len(columns)):
    col_name='col'+str(i+1)
    col_name = fits.Column(name=columns[i], format=data_format[i], array=df[columns[i]])
    cols.append(col_name)

hdu = fits.BinTableHDU.from_columns(cols)
hdu.writeto('D:\job\CSST\mock_catalog1\catalog_lephare/z_free.fits')




endtime = datetime.datetime.now()
usetime=endtime - starttime
print ('fits save Done')
print ('time use: %s'%(usetime))
print ('\n')


'''
#旧的存数据方法:
p0=np.zeros([len(GAL_rows)],dtype=int)
p1=np.zeros([len(STAR_rows)],dtype=int)+1
p2=np.zeros([len(QSO_rows)],dtype=int)+2
df1_galaxy=df1[GAL_rows]
df1_star=df1[STAR_rows]
df1_qso=df1[QSO_rows]

data1=np.column_stack((np.array(df1_galaxy),p0))
data2=np.column_stack((np.array(df1_star),p1))
data3=np.column_stack((np.array(df1_qso),p2))

#galaxy:
save1 = pd.DataFrame(data1, columns = ['id', 'MAG_AUTO_nuv', 'MAGERR_AUTO_nuv', 'MAG_AUTO_u', 'MAGERR_AUTO_u', 'MAG_AUTO_g', 'MAGERR_AUTO_g', 'MAG_AUTO_r', 'MAGERR_AUTO_r', 'MAG_AUTO_i', 'MAGERR_AUTO_i', 'MAG_AUTO_z', 'MAGERR_AUTO_z', 'MAG_AUTO_y', 'MAGERR_AUTO_y', 'photoz_sim', 'redshift', 'type', 'Ra', 'Dec', 'CLASS_STAR_nuv', 'CLASS_STAR_u', 'CLASS_STAR_g', 'CLASS_STAR_r', 'CLASS_STAR_i', 'CLASS_STAR_z', 'CLASS_STAR_y', 'CHI_BEST', 'MOD_BEST', 'EBV_BEST', 'NBAND_USED', 'CHI_QSO', 'MOD_QSO', 'MOD_STAR', 'CHI_STAR', 'MAG_MOD_nuv', 'MAG_MOD_u', 'MAG_MOD_g', 'MAG_MOD_r', 'MAG_MOD_i', 'MAG_MOD_z', 'MAG_MOD_y', 'CONTEXT', 'AGE_BEST', 'MASS_BEST', 'SFR_BEST', 'SSFR_BEST', 'SED_TYPE', 'type_xie']) #全部列数照搬，要减少列瘦身的方法：用topcat打开，选择列再保存瘦身版以及fits版。

#star:
save2 = pd.DataFrame(data2, columns = ['id', 'MAG_AUTO_nuv', 'MAGERR_AUTO_nuv', 'MAG_AUTO_u', 'MAGERR_AUTO_u', 'MAG_AUTO_g', 'MAGERR_AUTO_g', 'MAG_AUTO_r', 'MAGERR_AUTO_r', 'MAG_AUTO_i', 'MAGERR_AUTO_i', 'MAG_AUTO_z', 'MAGERR_AUTO_z', 'MAG_AUTO_y', 'MAGERR_AUTO_y', 'photoz_sim', 'redshift', 'type', 'Ra', 'Dec', 'CLASS_STAR_nuv', 'CLASS_STAR_u', 'CLASS_STAR_g', 'CLASS_STAR_r', 'CLASS_STAR_i', 'CLASS_STAR_z', 'CLASS_STAR_y', 'CHI_BEST', 'MOD_BEST', 'EBV_BEST', 'NBAND_USED', 'CHI_QSO', 'MOD_QSO', 'MOD_STAR', 'CHI_STAR', 'MAG_MOD_nuv', 'MAG_MOD_u', 'MAG_MOD_g', 'MAG_MOD_r', 'MAG_MOD_i', 'MAG_MOD_z', 'MAG_MOD_y', 'CONTEXT', 'AGE_BEST', 'MASS_BEST', 'SFR_BEST', 'SSFR_BEST', 'SED_TYPE', 'type_xie'])

#qso:
save3 = pd.DataFrame(data3, columns = ['id', 'MAG_AUTO_nuv', 'MAGERR_AUTO_nuv', 'MAG_AUTO_u', 'MAGERR_AUTO_u', 'MAG_AUTO_g', 'MAGERR_AUTO_g', 'MAG_AUTO_r', 'MAGERR_AUTO_r', 'MAG_AUTO_i', 'MAGERR_AUTO_i', 'MAG_AUTO_z', 'MAGERR_AUTO_z', 'MAG_AUTO_y', 'MAGERR_AUTO_y', 'photoz_sim', 'redshift', 'type', 'Ra', 'Dec', 'CLASS_STAR_nuv', 'CLASS_STAR_u', 'CLASS_STAR_g', 'CLASS_STAR_r', 'CLASS_STAR_i', 'CLASS_STAR_z', 'CLASS_STAR_y', 'CHI_BEST', 'MOD_BEST', 'EBV_BEST', 'NBAND_USED', 'CHI_QSO', 'MOD_QSO', 'MOD_STAR', 'CHI_STAR', 'MAG_MOD_nuv', 'MAG_MOD_u', 'MAG_MOD_g', 'MAG_MOD_r', 'MAG_MOD_i', 'MAG_MOD_z', 'MAG_MOD_y', 'CONTEXT', 'AGE_BEST', 'MASS_BEST', 'SFR_BEST', 'SSFR_BEST', 'SED_TYPE', 'type_xie'])

save1.to_csv('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/catalog_lephare/z_v3_x.csv',index=False)  
save2.to_csv('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/catalog_lephare/z_v3_x.csv',mode='a',header=0,index=False)  #header=0表示不保留列名，index=False表示不保留行索引，mode='a'表示附加方式写入，文件原有内容不会被清除
save3.to_csv('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/catalog_lephare/z_v3_x.csv',mode='a',header=0,index=False)  
'''


'''
#旧的存数据方法:
df1_galaxy=df1[GAL_rows]
df1_star=df1[STAR_rows]
df1_qso=df1[QSO_rows]

#galaxy:
data=np.array(df1_galaxy)
save = pd.DataFrame(data, columns = ['id', 'MAG_AUTO_nuv', 'MAGERR_AUTO_nuv', 'MAG_AUTO_u', 'MAGERR_AUTO_u', 'MAG_AUTO_g', 'MAGERR_AUTO_g', 'MAG_AUTO_r', 'MAGERR_AUTO_r', 'MAG_AUTO_i', 'MAGERR_AUTO_i', 'MAG_AUTO_z', 'MAGERR_AUTO_z', 'MAG_AUTO_y', 'MAGERR_AUTO_y', 'photoz_sim', 'redshift', 'type', 'Ra', 'Dec', 'CLASS_STAR_nuv', 'CLASS_STAR_u', 'CLASS_STAR_g', 'CLASS_STAR_r', 'CLASS_STAR_i', 'CLASS_STAR_z', 'CLASS_STAR_y', 'CHI_BEST', 'MOD_BEST', 'EBV_BEST', 'NBAND_USED', 'CHI_QSO', 'MOD_QSO', 'MOD_STAR', 'CHI_STAR', 'MAG_MOD_nuv', 'MAG_MOD_u', 'MAG_MOD_g', 'MAG_MOD_r', 'MAG_MOD_i', 'MAG_MOD_z', 'MAG_MOD_y', 'CONTEXT', 'AGE_BEST', 'MASS_BEST', 'SFR_BEST', 'SSFR_BEST', 'SED_TYPE']) #全部列数照搬，要减少列瘦身的方法：用topcat打开，选择列再保存瘦身版以及fits版。

save.to_csv('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/catalog_lephare/z_v3_x/galaxy.csv',index=False)  #,index=False表示不保留行索引



#star:
data=np.array(df1_star)
save = pd.DataFrame(data, columns = ['id', 'MAG_AUTO_nuv', 'MAGERR_AUTO_nuv', 'MAG_AUTO_u', 'MAGERR_AUTO_u', 'MAG_AUTO_g', 'MAGERR_AUTO_g', 'MAG_AUTO_r', 'MAGERR_AUTO_r', 'MAG_AUTO_i', 'MAGERR_AUTO_i', 'MAG_AUTO_z', 'MAGERR_AUTO_z', 'MAG_AUTO_y', 'MAGERR_AUTO_y', 'photoz_sim', 'redshift', 'type', 'Ra', 'Dec', 'CLASS_STAR_nuv', 'CLASS_STAR_u', 'CLASS_STAR_g', 'CLASS_STAR_r', 'CLASS_STAR_i', 'CLASS_STAR_z', 'CLASS_STAR_y', 'CHI_BEST', 'MOD_BEST', 'EBV_BEST', 'NBAND_USED', 'CHI_QSO', 'MOD_QSO', 'MOD_STAR', 'CHI_STAR', 'MAG_MOD_nuv', 'MAG_MOD_u', 'MAG_MOD_g', 'MAG_MOD_r', 'MAG_MOD_i', 'MAG_MOD_z', 'MAG_MOD_y', 'CONTEXT', 'AGE_BEST', 'MASS_BEST', 'SFR_BEST', 'SSFR_BEST', 'SED_TYPE']) #全部列数照搬，要减少列瘦身的方法：用topcat打开，选择列再保存瘦身版以及fits版。

save.to_csv('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/catalog_lephare/z_v3_x/star.csv',index=False)  #,index=False表示不保留行索引



#qso:
data=np.array(df1_qso)
save = pd.DataFrame(data, columns = ['id', 'MAG_AUTO_nuv', 'MAGERR_AUTO_nuv', 'MAG_AUTO_u', 'MAGERR_AUTO_u', 'MAG_AUTO_g', 'MAGERR_AUTO_g', 'MAG_AUTO_r', 'MAGERR_AUTO_r', 'MAG_AUTO_i', 'MAGERR_AUTO_i', 'MAG_AUTO_z', 'MAGERR_AUTO_z', 'MAG_AUTO_y', 'MAGERR_AUTO_y', 'photoz_sim', 'redshift', 'type', 'Ra', 'Dec', 'CLASS_STAR_nuv', 'CLASS_STAR_u', 'CLASS_STAR_g', 'CLASS_STAR_r', 'CLASS_STAR_i', 'CLASS_STAR_z', 'CLASS_STAR_y', 'CHI_BEST', 'MOD_BEST', 'EBV_BEST', 'NBAND_USED', 'CHI_QSO', 'MOD_QSO', 'MOD_STAR', 'CHI_STAR', 'MAG_MOD_nuv', 'MAG_MOD_u', 'MAG_MOD_g', 'MAG_MOD_r', 'MAG_MOD_i', 'MAG_MOD_z', 'MAG_MOD_y', 'CONTEXT', 'AGE_BEST', 'MASS_BEST', 'SFR_BEST', 'SSFR_BEST', 'SED_TYPE']) #全部列数照搬，要减少列瘦身的方法：用topcat打开，选择列再保存瘦身版以及fits版。

save.to_csv('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/catalog_lephare/z_v3_x/qso.csv',index=False)  #,index=False表示不保留行索引
'''
endtime = datetime.datetime.now()
usetime=endtime - starttime
print ('calaulate time use: %s'%(usetime))


'''
#chi_galaxy:
chi_galaxy=CHI_BEST/5.0
chi_galaxy_match=chi_galaxy[galaxy_match_rows]
chi_galaxy_lephare_notmatch=chi_galaxy[galaxy_notmatch_lephare]

#num_bins = 50  
#n, bins, patches =plt.hist(chi_galaxy_match, num_bins,density=1, facecolor='blue', alpha=0.5)  
plt.hist(chi_galaxy_match,bins=int((max(chi_galaxy_match)-min(chi_galaxy_match))/0.2),edgecolor='b',label=str(len(chi_galaxy_match))+' match')#,label='KIDS'
plt.xlabel('chi_galaxy_match')
plt.ylabel('number')
plt.xlim(0,50)
plt.title(str(len(chi_galaxy_match))+' galaxies of CSST')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/chi_galaxy_match.pdf')
plt.close('all')


#num_bins = 50  
#n, bins, patches =plt.hist(chi_galaxy_lephare_notmatch, num_bins,density=1, facecolor='blue', alpha=0.5)  
plt.hist(chi_galaxy_lephare_notmatch,bins=int((max(chi_galaxy_lephare_notmatch)-min(chi_galaxy_lephare_notmatch))/0.2),edgecolor='b',label=str(len(chi_galaxy_lephare_notmatch))+' lephare_notmatch')
plt.xlabel('chi_galaxy_lephare_notmatch')
plt.ylabel('number')
plt.xlim(0,50)
plt.title(str(len(chi_galaxy_lephare_notmatch))+' galaxies of CSST')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/chi_galaxy_lephare_notmatch.pdf')
plt.close('all')

#num_bins = 50  
#n, bins, patches =plt.hist(chi_galaxy_match, num_bins,density=1, facecolor='blue', alpha=0.5,label=str(len(chi_galaxy_match))+' match')  
#n, bins, patches =plt.hist(chi_galaxy_lephare_notmatch, num_bins,density=1, facecolor='red', alpha=0.5,label=str(len(chi_galaxy_lephare_notmatch))+' lephare_notmatch') 
plt.hist(chi_galaxy_match,bins=int((max(chi_galaxy_match)-min(chi_galaxy_match))/0.2),edgecolor='b',label=str(len(chi_galaxy_match))+' match')
plt.hist(chi_galaxy_lephare_notmatch,bins=int((max(chi_galaxy_lephare_notmatch)-min(chi_galaxy_lephare_notmatch))/0.2),edgecolor='red',label=str(len(chi_galaxy_lephare_notmatch))+' lephare_notmatch')
plt.xlabel('chi_galaxy')
plt.ylabel('number')
plt.xlim(0,50)
plt.legend()
plt.title(' chi_galaxy of CSST')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/chi_galaxy.pdf')
plt.close('all')





#chi_star:
chi_star=CHI_STAR/7.0
chi_star_star_lephare=chi_star[STAR_rows]
chi_star_star_to_galaxy=chi_star[star_to_galaxy]

num_bins = 50  
#n, bins, patches =plt.hist(chi_star_star_lephare, num_bins,density=1, facecolor='blue', alpha=0.5,label=str(len(STAR_rows))+' chi_star_star_lephare')
plt.hist(chi_star_star_lephare,bins=int((max(chi_star_star_lephare)-min(chi_star_star_lephare))/0.2),edgecolor='b')  
plt.xlabel('CHI_STAR')
plt.ylabel('number')
plt.xlim(0,100)
plt.legend()
plt.title(' chi_star of star')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/chi_star.pdf')
plt.close('all')

num_bins = 50  
#n, bins, patches =plt.hist(chi_star_star_lephare, num_bins,density=1, facecolor='blue', alpha=0.5,label=str(len(STAR_rows))+' chi_star_star_lephare')  
#n, bins, patches =plt.hist(chi_star_star_to_galaxy, num_bins,density=1, facecolor='red', alpha=1.0,label=str(len(star_to_galaxy))+' chi_star of star_to_galaxy')
plt.hist(chi_star_star_lephare,bins=int((max(chi_star_star_lephare)-min(chi_star_star_lephare))/0.2),edgecolor='b',label=str(len(STAR_rows))+' chi_star_star_lephare') 
plt.hist(chi_star_star_to_galaxy,bins=int((max(chi_star_star_to_galaxy)-min(chi_star_star_to_galaxy))/0.2),edgecolor='red',label=str(len(star_to_galaxy))+' chi_star of star_to_galaxy') 
plt.xlabel('chi_star')
plt.ylabel('number')
plt.xlim(0,100)
plt.legend()
plt.title(' chi_star')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/chi_star_x.pdf')
plt.close('all')




#chi_qso:
chi_qso=CHI_QSO/6.0
chi_qso_qso_lephare=chi_qso[QSO_rows]
chi_qso_qso_to_galaxy=chi_qso[qso_to_galaxy]

#num_bins = 50  
#n, bins, patches =plt.hist(chi_qso_qso_lephare, num_bins,density=1, facecolor='blue', alpha=0.5,label=str(len(QSO_rows))+' chi_qso_qso_lephare') 
plt.hist(chi_qso_qso_lephare,bins=int((max(chi_qso_qso_lephare)-min(chi_qso_qso_lephare))/0.2),edgecolor='b')  
plt.xlabel('chi_qso')
plt.ylabel('number')
plt.xlim(0,200)
plt.legend()
plt.title(' chi_qso of qso')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/chi_qso.pdf')
plt.close('all')

#num_bins = 50  
#n, bins, patches =plt.hist(chi_qso_qso_lephare, num_bins,density=1, facecolor='blue', alpha=0.5,label=str(len(QSO_rows))+' chi_qso_qso_lephare')  
#n, bins, patches =plt.hist(chi_qso_qso_to_galaxy, num_bins,density=1, facecolor='red', alpha=0.5,label=str(len(qso_to_galaxy))+' chi_qso of qso_to_galaxy')
plt.hist(chi_qso_qso_lephare,bins=int((max(chi_qso_qso_lephare)-min(chi_qso_qso_lephare))/0.2),edgecolor='b',label=str(len(QSO_rows))+' chi_qso_qso_lephare') 
plt.hist(chi_qso_qso_to_galaxy,bins=int((max(chi_qso_qso_to_galaxy)-min(chi_qso_qso_to_galaxy))/0.2),edgecolor='red',label=str(len(qso_to_galaxy))+' chi_qso of qso_to_galaxy') 
plt.xlabel('chi_qso')
plt.ylabel('number')
plt.xlim(0,100)
plt.legend()
plt.title(' chi_qso')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/chi_qso_x.pdf')
plt.close('all')




#CLASS_STAR_r:
CLASS_STAR_r_galaxy_lephare=CLASS_STAR_r[GAL_rows]
CLASS_STAR_r_qso_to_galaxy=CLASS_STAR_r[qso_to_galaxy]
CLASS_STAR_r_star_to_galaxy=CLASS_STAR_r[star_to_galaxy]

num_bins = 50  
#n, bins, patches =plt.hist(CLASS_STAR_r_galaxy_lephare, num_bins,density=1, facecolor='blue', alpha=0.5,label=str(len(GAL_rows))+' CLASS_STAR_r_galaxy_lephare')  
plt.hist(CLASS_STAR_r_galaxy_lephare,bins=int((max(CLASS_STAR_r_galaxy_lephare)-min(CLASS_STAR_r_galaxy_lephare))/0.2),edgecolor='b',label=str(len(GAL_rows))+' CLASS_STAR_r_galaxy_lephare') 
plt.xlabel('CLASS_STAR_r')
plt.ylabel('number')
#plt.xlim(0,300)
plt.legend()
plt.title(' CLASS_STAR_r of galaxy')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/CLASS_STAR_r_galaxy.pdf')
plt.close('all')

#num_bins = 50  
#n, bins, patches =plt.hist(CLASS_STAR_r_galaxy_lephare, num_bins,density=1, facecolor='blue', alpha=0.5,label=str(len(GAL_rows))+' CLASS_STAR_r_galaxy_lephare')  
#n, bins, patches =plt.hist(CLASS_STAR_r_qso_to_galaxy, num_bins,density=1, facecolor='red', alpha=1,label=str(len(qso_to_galaxy))+' CLASS_STAR_r of qso_to_galaxy') 
#n, bins, patches =plt.hist(CLASS_STAR_r_star_to_galaxy, num_bins,density=1, facecolor='green', alpha=1,label=str(len(star_to_galaxy))+' CLASS_STAR_r of star_to_galaxy')
plt.hist(CLASS_STAR_r_galaxy_lephare,bins=int((max(CLASS_STAR_r_galaxy_lephare)-min(CLASS_STAR_r_galaxy_lephare))/0.2),edgecolor='b',label=str(len(GAL_rows))+' CLASS_STAR_r_galaxy_lephare') 
plt.hist(CLASS_STAR_r_qso_to_galaxy,bins=int((max(CLASS_STAR_r_qso_to_galaxy)-min(CLASS_STAR_r_qso_to_galaxy))/0.2),edgecolor='b',label=str(len(qso_to_galaxy))+' CLASS_STAR_r of qso_to_galaxy') 
plt.hist(CLASS_STAR_r_star_to_galaxy,bins=int((max(CLASS_STAR_r_star_to_galaxy)-min(CLASS_STAR_r_star_to_galaxy))/0.2),edgecolor='b',label=str(len(star_to_galaxy))+' CLASS_STAR_r of star_to_galaxy') 
plt.xlabel('CLASS_STAR_r')
plt.ylabel('number')
#plt.xlim(0,300)
plt.legend()
plt.title(' CLASS_STAR_r of galaxy')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/CLASS_STAR_r_galaxy_x.pdf')
plt.close('all')
'''





#match:
MAG_AUTO_g_galaxy_lephare_notmatch=MAG_AUTO_g[galaxy_notmatch_lephare]
MAG_AUTO_g_star_lephare_notmatch=MAG_AUTO_g[star_notmatch_lephare]
MAG_AUTO_g_qso_lephare_notmatch=MAG_AUTO_g[qso_notmatch_lephare]
MAG_AUTO_g_galaxy_true_notmatch=MAG_AUTO_g[galaxy_notmatch_true]
MAG_AUTO_g_star_true_notmatch=MAG_AUTO_g[star_notmatch_true]
MAG_AUTO_g_qso_true_notmatch=MAG_AUTO_g[qso_notmatch_true]
MAG_AUTO_g_galaxy_match=MAG_AUTO_g[galaxy_match_rows]
MAG_AUTO_g_star_match=MAG_AUTO_g[star_match_rows]
MAG_AUTO_g_qso_match=MAG_AUTO_g[qso_match_rows]

MAG_AUTO_r_galaxy_lephare_notmatch=MAG_AUTO_r[galaxy_notmatch_lephare]
MAG_AUTO_r_star_lephare_notmatch=MAG_AUTO_r[star_notmatch_lephare]
MAG_AUTO_r_qso_lephare_notmatch=MAG_AUTO_r[qso_notmatch_lephare]
MAG_AUTO_r_galaxy_true_notmatch=MAG_AUTO_r[galaxy_notmatch_true]
MAG_AUTO_r_star_true_notmatch=MAG_AUTO_r[star_notmatch_true]
MAG_AUTO_r_qso_true_notmatch=MAG_AUTO_r[qso_notmatch_true]
MAG_AUTO_r_galaxy_match=MAG_AUTO_r[galaxy_match_rows]
MAG_AUTO_r_star_match=MAG_AUTO_r[star_match_rows]
MAG_AUTO_r_qso_match=MAG_AUTO_r[qso_match_rows]


MAG_AUTO_y_galaxy_lephare_notmatch=MAG_AUTO_y[galaxy_notmatch_lephare]
MAG_AUTO_y_star_lephare_notmatch=MAG_AUTO_y[star_notmatch_lephare]
MAG_AUTO_y_qso_lephare_notmatch=MAG_AUTO_y[qso_notmatch_lephare]
MAG_AUTO_y_galaxy_true_notmatch=MAG_AUTO_y[galaxy_notmatch_true]
MAG_AUTO_y_star_true_notmatch=MAG_AUTO_y[star_notmatch_true]
MAG_AUTO_y_qso_true_notmatch=MAG_AUTO_y[qso_notmatch_true]
MAG_AUTO_y_galaxy_match=MAG_AUTO_y[galaxy_match_rows]
MAG_AUTO_y_star_match=MAG_AUTO_y[star_match_rows]
MAG_AUTO_y_qso_match=MAG_AUTO_y[qso_match_rows]

g_y_galaxy_lephare_notmatch=g_y[galaxy_notmatch_lephare]
g_y_star_lephare_notmatch=g_y[star_notmatch_lephare]
g_y_qso_lephare_notmatch=g_y[qso_notmatch_lephare]
g_y_galaxy_true_notmatch=g_y[galaxy_notmatch_true]
g_y_star_true_notmatch=g_y[star_notmatch_true]
g_y_qso_true_notmatch=g_y[qso_notmatch_true]
g_y_galaxy_match=g_y[galaxy_match_rows]
g_y_star_match=g_y[star_match_rows]
g_y_qso_match=g_y[qso_match_rows]

z_y_galaxy_lephare_notmatch=z_y[galaxy_notmatch_lephare]
z_y_star_lephare_notmatch=z_y[star_notmatch_lephare]
z_y_qso_lephare_notmatch=z_y[qso_notmatch_lephare]
z_y_galaxy_true_notmatch=z_y[galaxy_notmatch_true]
z_y_star_true_notmatch=z_y[star_notmatch_true]
z_y_qso_true_notmatch=z_y[qso_notmatch_true]
z_y_galaxy_match=z_y[galaxy_match_rows]
z_y_star_match=z_y[star_match_rows]
z_y_qso_match=z_y[qso_match_rows]

g_z_galaxy_lephare_notmatch=g_z[galaxy_notmatch_lephare]
g_z_star_lephare_notmatch=g_z[star_notmatch_lephare]
g_z_qso_lephare_notmatch=g_z[qso_notmatch_lephare]
g_z_galaxy_true_notmatch=g_z[galaxy_notmatch_true]
g_z_star_true_notmatch=g_z[star_notmatch_true]
g_z_qso_true_notmatch=g_z[qso_notmatch_true]
g_z_galaxy_match=g_z[galaxy_match_rows]
g_z_star_match=g_z[star_match_rows]
g_z_qso_match=g_z[qso_match_rows]


g_r_galaxy_lephare_notmatch=g_r[galaxy_notmatch_lephare]
g_r_star_lephare_notmatch=g_r[star_notmatch_lephare]
g_r_qso_lephare_notmatch=g_r[qso_notmatch_lephare]
g_r_galaxy_true_notmatch=g_r[galaxy_notmatch_true]
g_r_star_true_notmatch=g_r[star_notmatch_true]
g_r_qso_true_notmatch=g_r[qso_notmatch_true]
g_r_galaxy_match=g_r[galaxy_match_rows]
g_r_star_match=g_r[star_match_rows]
g_r_qso_match=g_r[qso_match_rows]

u_r_galaxy_lephare_notmatch=u_r[galaxy_notmatch_lephare]
u_r_star_lephare_notmatch=u_r[star_notmatch_lephare]
u_r_qso_lephare_notmatch=u_r[qso_notmatch_lephare]
u_r_galaxy_true_notmatch=u_r[galaxy_notmatch_true]
u_r_star_true_notmatch=u_r[star_notmatch_true]
u_r_qso_true_notmatch=u_r[qso_notmatch_true]
u_r_galaxy_match=u_r[galaxy_match_rows]
u_r_star_match=u_r[star_match_rows]
u_r_qso_match=u_r[qso_match_rows]

nuv_r_galaxy_lephare_notmatch=nuv_r[galaxy_notmatch_lephare]
nuv_r_star_lephare_notmatch=nuv_r[star_notmatch_lephare]
nuv_r_qso_lephare_notmatch=nuv_r[qso_notmatch_lephare]
nuv_r_galaxy_true_notmatch=nuv_r[galaxy_notmatch_true]
nuv_r_star_true_notmatch=nuv_r[star_notmatch_true]
nuv_r_qso_true_notmatch=nuv_r[qso_notmatch_true]
nuv_r_galaxy_match=nuv_r[galaxy_match_rows]
nuv_r_star_match=nuv_r[star_match_rows]
nuv_r_qso_match=nuv_r[qso_match_rows]

nuv_u_galaxy_lephare_notmatch=nuv_u[galaxy_notmatch_lephare]
nuv_u_star_lephare_notmatch=nuv_u[star_notmatch_lephare]
nuv_u_qso_lephare_notmatch=nuv_u[qso_notmatch_lephare]
nuv_u_galaxy_true_notmatch=nuv_u[galaxy_notmatch_true]
nuv_u_star_true_notmatch=nuv_u[star_notmatch_true]
nuv_u_qso_true_notmatch=nuv_u[qso_notmatch_true]
nuv_u_galaxy_match=nuv_u[galaxy_match_rows]
nuv_u_star_match=nuv_u[star_match_rows]
nuv_u_qso_match=nuv_u[qso_match_rows]

nuv_g_galaxy_lephare_notmatch=nuv_g[galaxy_notmatch_lephare]
nuv_g_star_lephare_notmatch=nuv_g[star_notmatch_lephare]
nuv_g_qso_lephare_notmatch=nuv_g[qso_notmatch_lephare]
nuv_g_galaxy_true_notmatch=nuv_g[galaxy_notmatch_true]
nuv_g_star_true_notmatch=nuv_g[star_notmatch_true]
nuv_g_qso_true_notmatch=nuv_g[qso_notmatch_true]
nuv_g_galaxy_match=nuv_g[galaxy_match_rows]
nuv_g_star_match=nuv_g[star_match_rows]
nuv_g_qso_match=nuv_g[qso_match_rows]

g_z_galaxy_to_star=g_z[galaxy_to_star]
g_z_galaxy_to_qso=g_z[galaxy_to_qso]
g_z_star_to_galaxy=g_z[star_to_galaxy]
g_z_star_to_qso=g_z[star_to_qso]
g_z_qso_to_galaxy=g_z[qso_to_galaxy]
g_z_qso_to_star=g_z[qso_to_star]

g_y_galaxy_to_star=g_y[galaxy_to_star]
g_y_galaxy_to_qso=g_y[galaxy_to_qso]
g_y_star_to_galaxy=g_y[star_to_galaxy]
g_y_star_to_qso=g_y[star_to_qso]
g_y_qso_to_galaxy=g_y[qso_to_galaxy]
g_y_qso_to_star=g_y[qso_to_star]


z_y_galaxy_to_star=z_y[galaxy_to_star]
z_y_galaxy_to_qso=z_y[galaxy_to_qso]
z_y_star_to_galaxy=z_y[star_to_galaxy]
z_y_star_to_qso=z_y[star_to_qso]
z_y_qso_to_galaxy=z_y[qso_to_galaxy]
z_y_qso_to_star=z_y[qso_to_star]

#notmatch:
MAG_AUTO_r_star_to_galaxy=MAG_AUTO_g[star_to_galaxy]
CLASS_STAR_r_star_to_galaxy=CLASS_STAR_r[star_to_galaxy]
#lephare:
MAG_AUTO_g_galaxy_lephare=MAG_AUTO_g[GAL_rows]
MAG_AUTO_g_star_lephare=MAG_AUTO_g[STAR_rows]
MAG_AUTO_g_qso_lephare=MAG_AUTO_g[QSO_rows]

MAG_AUTO_r_galaxy_lephare=MAG_AUTO_r[GAL_rows]
CLASS_STAR_r_galaxy_lephare=CLASS_STAR_r[GAL_rows]

MAG_AUTO_r_galaxy_lephare=MAG_AUTO_r[GAL_rows]
MAG_AUTO_r_star_lephare=MAG_AUTO_r[STAR_rows]
MAG_AUTO_r_qso_lephare=MAG_AUTO_r[QSO_rows]

MAG_AUTO_y_galaxy_lephare=MAG_AUTO_y[GAL_rows]
MAG_AUTO_y_star_lephare=MAG_AUTO_y[STAR_rows]
MAG_AUTO_y_qso_lephare=MAG_AUTO_y[QSO_rows]

z_y_galaxy_lephare=z_y[GAL_rows]
z_y_star_lephare=z_y[STAR_rows]
z_y_qso_lephare=z_y[QSO_rows]

g_z_galaxy_lephare=g_z[GAL_rows]
g_z_star_lephare=g_z[STAR_rows]
g_z_qso_lephare=g_z[QSO_rows]

g_y_galaxy_lephare=g_y[GAL_rows]
g_y_star_lephare=g_y[STAR_rows]
g_y_qso_lephare=g_y[QSO_rows]

g_r_galaxy_lephare=g_r[GAL_rows]
g_r_star_lephare=g_r[STAR_rows]
g_r_qso_lephare=g_r[QSO_rows]

u_r_galaxy_lephare=u_r[GAL_rows]
u_r_star_lephare=u_r[STAR_rows]
u_r_qso_lephare=u_r[QSO_rows]

nuv_r_galaxy_lephare=nuv_r[GAL_rows]
nuv_r_star_lephare=nuv_r[STAR_rows]
nuv_r_qso_lephare=nuv_r[QSO_rows]

nuv_g_galaxy_lephare=nuv_g[GAL_rows]
nuv_g_star_lephare=nuv_g[STAR_rows]
nuv_g_qso_lephare=nuv_g[QSO_rows]

nuv_u_galaxy_lephare=nuv_u[GAL_rows]
nuv_u_star_lephare=nuv_u[STAR_rows]
nuv_u_qso_lephare=nuv_u[QSO_rows]


#true:
MAG_AUTO_g_galaxy_true=MAG_AUTO_g[rows_galaxy_true]
MAG_AUTO_g_star_true=MAG_AUTO_g[rows_star_true]
MAG_AUTO_g_qso_true=MAG_AUTO_g[rows_qso_true]

MAG_AUTO_r_galaxy_true=MAG_AUTO_r[rows_galaxy_true]
MAG_AUTO_r_star_true=MAG_AUTO_r[rows_star_true]
MAG_AUTO_r_qso_true=MAG_AUTO_r[rows_qso_true]

MAG_AUTO_y_galaxy_true=MAG_AUTO_y[rows_galaxy_true]
MAG_AUTO_y_star_true=MAG_AUTO_y[rows_star_true]
MAG_AUTO_y_qso_true=MAG_AUTO_y[rows_qso_true]

z_y_galaxy_true=z_y[rows_galaxy_true]
z_y_star_true=z_y[rows_star_true]
z_y_qso_true=z_y[rows_qso_true]

g_z_galaxy_true=g_z[rows_galaxy_true]
g_z_star_true=g_z[rows_star_true]
g_z_qso_true=g_z[rows_qso_true]

g_y_galaxy_true=g_y[rows_galaxy_true]
g_y_star_true=g_y[rows_star_true]
g_y_qso_true=g_y[rows_qso_true]

g_r_galaxy_true=g_r[rows_galaxy_true]
g_r_star_true=g_r[rows_star_true]
g_r_qso_true=g_r[rows_qso_true]

u_r_galaxy_true=u_r[rows_galaxy_true]
u_r_star_true=u_r[rows_star_true]
u_r_qso_true=u_r[rows_qso_true]

nuv_r_galaxy_true=nuv_r[rows_galaxy_true]
nuv_r_star_true=nuv_r[rows_star_true]
nuv_r_qso_true=nuv_r[rows_qso_true]

nuv_g_galaxy_true=nuv_g[rows_galaxy_true]
nuv_g_star_true=nuv_g[rows_star_true]
nuv_g_qso_true=nuv_g[rows_qso_true]

nuv_u_galaxy_true=nuv_u[rows_galaxy_true]
nuv_u_star_true=nuv_u[rows_star_true]
nuv_u_qso_true=nuv_u[rows_qso_true]




'''
#MAG_AUTO_r vs CLASS_STAR_r:
plt.hist2d(MAG_AUTO_r_star_to_galaxy,CLASS_STAR_r_star_to_galaxy,bins=100,norm=LogNorm(),cmap='RdYlBu')
plt.ylabel('CLASS_STAR_r')
plt.xlabel('MAG_AUTO_r')
#plt.xlim(-1.5,1.5)
#plt.ylim(-3,5)
#plt.legend()
plt.title(str(len(star_to_galaxy))+' star_to_galaxy')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/mag_r_class_star_star_to_galaxy.pdf')
plt.close()


y=[0.0,0.3,0.6,0.8,1.0]
x=[25.5,25.5,25.5,25.5,25.5]
plt.hist2d(MAG_AUTO_r_galaxy_lephare,CLASS_STAR_r_galaxy_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.scatter(MAG_AUTO_r_star_to_galaxy,CLASS_STAR_r_star_to_galaxy,s=8,color='k',alpha=0.6,label=str(len(star_to_galaxy))+' star_to_galaxy')
plt.plot(x,y,color='k',lw=1.0,label='x=25.5')
plt.ylabel('CLASS_STAR_r')
plt.xlabel('MAG_AUTO_r')
plt.xlim(17,29)
plt.ylim(0,1)
plt.legend()
plt.title(str(len(GAL_rows))+' galaxy_lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/mag_r_class_star_galaxy_lephare.pdf')
plt.close()
'''
'''
#plot:
#=============================================================================
#lephare 图：
#g-z vs z-y:
plt.hist2d(z_y_galaxy_lephare,g_z_galaxy_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
#plt.legend()
plt.title(str(len(GAL_rows))+' galaxies of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_galaxy_lephare.pdf')
plt.close()

plt.hist2d(z_y_galaxy_lephare,g_z_galaxy_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.scatter(z_y_star_to_galaxy,g_z_star_to_galaxy,color='g',label='star_to_galaxy: '+str(len(z_y_star_to_galaxy)),s=1)
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
plt.legend()
plt.title(str(len(GAL_rows))+' stars of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_galaxy_lepharex1.pdf')
plt.close()

plt.hist2d(z_y_galaxy_lephare,g_z_galaxy_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.scatter(z_y_qso_to_galaxy,g_z_qso_to_galaxy,color='g',label='qso_to_galaxy: '+str(len(z_y_qso_to_galaxy)),s=1)
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
plt.legend()
plt.title(str(len(GAL_rows))+' stars of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_galaxy_lepharex2.pdf')
plt.close()



plt.hist2d(z_y_star_lephare,g_z_star_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
plt.title(str(len(STAR_rows))+' stars of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_star_lephare.pdf')
plt.close()

plt.hist2d(z_y_star_lephare,g_z_star_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.scatter(z_y_galaxy_to_star,g_z_galaxy_to_star,color='g',label='galaxy_to_star: '+str(len(z_y_galaxy_to_star)),s=1)
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
plt.legend()
plt.title(str(len(STAR_rows))+' stars of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_star_lepharex1.pdf')
plt.close()

plt.hist2d(z_y_star_lephare,g_z_star_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.scatter(z_y_qso_to_star,g_z_qso_to_star,color='g',label='qso_to_star: '+str(len(z_y_qso_to_star)),s=1)
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
plt.legend()
plt.title(str(len(STAR_rows))+' stars of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_star_lepharex2.pdf')
plt.close()

plt.hist2d(z_y_qso_lephare,g_z_qso_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
plt.title(str(len(QSO_rows))+' qsos of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_qso_lephare.pdf')
plt.close()

plt.hist2d(z_y_qso_lephare,g_z_qso_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.scatter(z_y_galaxy_to_qso,g_z_galaxy_to_qso,color='g',label='galaxy_to_qso: '+str(len(z_y_galaxy_to_qso)),s=1)
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
plt.legend()
plt.title(str(len(QSO_rows))+' qsos of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_qso_lepharex1.pdf')
plt.close()

plt.hist2d(z_y_qso_lephare,g_z_qso_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.scatter(z_y_star_to_qso,g_z_star_to_qso,color='g',label='star_to_qso: '+str(len(z_y_star_to_qso)),s=1)
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
plt.legend()
plt.title(str(len(QSO_rows))+' stars of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_qso_lepharex2.pdf')
plt.close()




#g vs g-z:
plt.hist2d(MAG_AUTO_g_galaxy_lephare,g_z_galaxy_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('g')
plt.ylabel('g-z')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(GAL_rows))+' galaxies of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-z_galaxy_lephare.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_star_lephare,g_z_star_lephare,bins=100,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('g')
plt.ylabel('g-z')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(STAR_rows))+' stars of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-z_star_lephare.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_qso_lephare,g_z_qso_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('g')
plt.ylabel('g-z')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(QSO_rows))+' qsos of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-z_qso_lephare.pdf')
plt.close()
'''
'''
#true 图：
#g-z vs z-y:
plt.hist2d(z_y_galaxy_true,g_z_galaxy_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
#plt.legend()
plt.title(str(len(rows_galaxy_true))+' galaxies of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_galaxy_true.pdf')
plt.close()


plt.hist2d(z_y_star_true,g_z_star_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
plt.title(str(len(rows_star_true))+' stars of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_star_true.pdf')
plt.close()



plt.hist2d(z_y_qso_true,g_z_qso_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
plt.title(str(len(rows_qso_true))+' qsos of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_qso_true.pdf')
plt.close()





#g vs g-z:
plt.hist2d(MAG_AUTO_g_galaxy_true,g_z_galaxy_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('g')
plt.ylabel('g-z')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(rows_galaxy_true))+' galaxies of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-z_galaxy_true.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_star_true,g_z_star_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('g')
plt.ylabel('g-z')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(rows_star_true))+' stars of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-z_star_true.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_qso_true,g_z_qso_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('g')
plt.ylabel('g-z')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(rows_qso_true))+' qsos of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-z_qso_true.pdf')
plt.close()




#match:
#g_z vs z_y:
#galaxy:
plt.hist2d(z_y_galaxy_match,g_z_galaxy_match,bins=300,norm=LogNorm(),cmap='Reds',alpha=1)
plt.hist2d(z_y_galaxy_true_notmatch,g_z_galaxy_true_notmatch,bins=30,norm=LogNorm(),cmap='Greens')
plt.hist2d(z_y_galaxy_lephare_notmatch,g_z_galaxy_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues',alpha=1)
#plt.scatter(z_y_galaxy_lephare_notmatch,g_z_galaxy_lephare_notmatch)
#plt.colorbar(label='Count')
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
#plt.legend()
plt.title('galaxy')
plt.text(-1.4,3.5,'not_match _lephare: '+str(len(galaxy_notmatch_lephare))+'\n'+'not_match _true: '+str(len(galaxy_notmatch_true))+'\n'+'match: '+str(len(galaxy_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_galaxy.pdf')
plt.close()

plt.hist2d(z_y_galaxy_lephare_notmatch,g_z_galaxy_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
#plt.colorbar(label='Count')
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
#plt.legend()
plt.title(str(len(galaxy_notmatch_lephare))+' galaxies of not_match _lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_galaxy1.pdf')
plt.close()

plt.hist2d(z_y_galaxy_true_notmatch,g_z_galaxy_true_notmatch,bins=30,norm=LogNorm(),cmap='Greens')
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
#plt.legend()
plt.title(str(len(galaxy_notmatch_true))+' galaxies of not_match _true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_galaxy2.pdf')
plt.close()


plt.hist2d(z_y_galaxy_match,g_z_galaxy_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
#plt.legend()
plt.title(str(len(galaxy_match_rows))+' galaxies of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_galaxy3.pdf')
plt.close()




#star:
plt.hist2d(z_y_star_match,g_z_star_match,bins=80,norm=LogNorm(),cmap='Reds')
plt.hist2d(z_y_star_true_notmatch,g_z_star_true_notmatch,bins=600,norm=LogNorm(),cmap='Greens')#star_true_notmatch,bins=600
plt.hist2d(z_y_star_lephare_notmatch,g_z_star_lephare_notmatch,bins=180,norm=LogNorm(),cmap='Blues')
#plt.colorbar(label='KIDS4('+str(len(z_ys2))+' stars)')
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
#plt.legend()
plt.title('star')
plt.text(-1.3,3,'not_match _lephare: '+str(len(star_notmatch_lephare))+'\n'+'not_match _true: '+str(len(star_notmatch_true))+'\n'+'match: '+str(len(star_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_star.pdf')
plt.close()

plt.hist2d(z_y_star_lephare_notmatch,g_z_star_lephare_notmatch,bins=180,norm=LogNorm(),cmap='Blues')
#plt.colorbar(label='Count')
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
#plt.legend()
plt.title(str(len(star_notmatch_lephare))+' stars of not_match _lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_star1.pdf')
plt.close()

plt.hist2d(z_y_star_true_notmatch,g_z_star_true_notmatch,bins=600,norm=LogNorm(),cmap='Greens')#star_true_notmatch,bins=600
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
#plt.legend()
plt.title(str(len(star_notmatch_true))+' stars of not_match _true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_star2.pdf')
plt.close()

plt.hist2d(z_y_star_match,g_z_star_match,bins=80,norm=LogNorm(),cmap='Reds')
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
#plt.legend()
plt.title(str(len(star_match_rows))+' stars of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_star3.pdf')
plt.close()



#qso:
plt.hist2d(z_y_qso_true_notmatch,g_z_qso_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.hist2d(z_y_qso_match,g_z_qso_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.hist2d(z_y_qso_lephare_notmatch,g_z_qso_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
#plt.colorbar(label='KIDS4('+str(len(z_ys3))+' qsos)')
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
#plt.legend()
plt.title('qso')
plt.text(-1.4,-2.8,'not_match _lephare: '+str(len(qso_notmatch_lephare))+'\n'+'not_match _true: '+str(len(qso_notmatch_true))+'\n'+'match: '+str(len(qso_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_qso.pdf')
plt.close()


plt.hist2d(z_y_qso_lephare_notmatch,g_z_qso_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
#plt.colorbar(label='KIDS4('+str(len(z_ys3))+' qsos)')
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
#plt.legend()
plt.title(str(len(qso_notmatch_lephare))+' qsos of not_match _lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_qso1.pdf')
plt.close()

plt.hist2d(z_y_qso_true_notmatch,g_z_qso_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
#plt.legend()
plt.title(str(len(qso_notmatch_true))+' qsos of not_match _true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_qso2.pdf')
plt.close()


plt.hist2d(z_y_qso_match,g_z_qso_match,bins=300,norm=LogNorm(),cmap='Reds')
#plt.colorbar(label='KIDS4('+str(len(z_ys3))+' qsos)')
plt.ylabel('g-z')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,5)
#plt.legend()
plt.title(str(len(qso_match_rows))+' qsos of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g-z_z-y_qso3.pdf')
plt.close()




#g vs z-y:
#galaxy:
plt.hist2d(MAG_AUTO_g_galaxy_match,z_y_galaxy_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.hist2d(MAG_AUTO_g_galaxy_lephare_notmatch,z_y_galaxy_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
plt.hist2d(MAG_AUTO_g_galaxy_true_notmatch,z_y_galaxy_true_notmatch,bins=30,norm=LogNorm(),cmap='Greens')
#plt.colorbar(label='KIDS4('+str(len(z_ys1))+' galaxies)')
plt.xlabel('g')
plt.ylabel('z-y')
plt.ylim(-1.5,1.5)
plt.xlim(15,30)
#plt.legend()
plt.title('galaxy')
plt.text(16.1,-1.4,'not_match _lephare: '+str(len(galaxy_notmatch_lephare))+'\n'+'not_match _true: '+str(len(galaxy_notmatch_true))+'\n'+'match: '+str(len(galaxy_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_z-y_galaxy.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_galaxy_match,z_y_galaxy_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.xlabel('g')
plt.ylabel('z-y')
plt.ylim(-1.5,1.5)
plt.xlim(15,30)
#plt.legend()
plt.title(str(len(galaxy_match_rows))+' galaxy of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_z-y_galaxy1.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_galaxy_lephare_notmatch,z_y_galaxy_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
plt.xlabel('g')
plt.ylabel('z-y')
plt.ylim(-1.5,1.5)
plt.xlim(15,30)
#plt.legend()
plt.title(str(len(galaxy_notmatch_lephare))+' galaxy of not_match _lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_z-y_galaxy2.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_galaxy_true_notmatch,z_y_galaxy_true_notmatch,bins=30,norm=LogNorm(),cmap='Greens')
plt.xlabel('g')
plt.ylabel('z-y')
plt.ylim(-1.5,1.5)
plt.xlim(15,30)
#plt.legend()
plt.title(str(len(galaxy_notmatch_true))+' galaxy of not_match _true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_z-y_galaxy3.pdf')
plt.close()



#star:
plt.hist2d(MAG_AUTO_g_star_match,z_y_star_match,bins=80,norm=LogNorm(),cmap='Reds')#star_match:80 
plt.hist2d(MAG_AUTO_g_star_true_notmatch,z_y_star_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.hist2d(MAG_AUTO_g_star_lephare_notmatch,z_y_star_lephare_notmatch,bins=180,norm=LogNorm(),cmap='Blues')#star_lephare_notmatch:70,或180，或300
#plt.colorbar(label='KIDS4('+str(len(z_ys2))+' stars)')
plt.xlabel('g')
plt.ylabel('z-y')
plt.ylim(-1.5,1.5)
plt.xlim(15,30)
#plt.legend()
plt.title('star')
plt.text(16.1,-1.4,'not_match _lephare: '+str(len(star_notmatch_lephare))+'\n'+'not_match _true: '+str(len(star_notmatch_true))+'\n'+'match: '+str(len(star_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_z-y_star.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_star_match,z_y_star_match,bins=80,norm=LogNorm(),cmap='Reds')
plt.xlabel('g')
plt.ylabel('z-y')
plt.ylim(-1.5,1.5)
plt.xlim(15,30)
#plt.legend()
plt.title(str(len(star_match_rows))+' star of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_z-y_star1.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_star_true_notmatch,z_y_star_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.xlabel('g')
plt.ylabel('z-y')
plt.ylim(-1.5,1.5)
plt.xlim(15,30)
#plt.legend()
plt.title(str(len(star_notmatch_true))+' star of notmatch_true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_z-y_star2.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_star_lephare_notmatch,z_y_star_lephare_notmatch,bins=180,norm=LogNorm(),cmap='Blues')
#plt.colorbar(label='KIDS4('+str(len(z_ys2))+' stars)')
plt.xlabel('g')
plt.ylabel('z-y')
plt.ylim(-1.5,1.5)
plt.xlim(15,30)
#plt.legend()
plt.title(str(len(star_notmatch_lephare))+' star of notmatch_lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_z-y_star3.pdf')
plt.close()

#qso:
plt.hist2d(MAG_AUTO_g_qso_true_notmatch,z_y_qso_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.hist2d(MAG_AUTO_g_qso_match,z_y_qso_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.hist2d(MAG_AUTO_g_qso_lephare_notmatch,z_y_qso_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
plt.xlabel('g')
plt.ylabel('z-y')
plt.ylim(-1.5,1.5)
plt.xlim(15,30)
#plt.legend()
plt.title('qso')
plt.text(16.1,-1.2,'not_match _lephare: '+str(len(qso_notmatch_lephare))+'\n'+'not_match _true: '+str(len(qso_notmatch_true))+'\n'+'match: '+str(len(qso_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_z-y_qso.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_qso_true_notmatch,z_y_qso_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.xlabel('g')
plt.ylabel('z-y')
plt.ylim(-1.5,1.5)
plt.xlim(15,30)
#plt.legend()
plt.title(str(len(qso_notmatch_true))+' qso of notmatch_true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_z-y_qso1.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_qso_match,z_y_qso_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.xlabel('g')
plt.ylabel('z-y')
plt.ylim(-1.5,1.5)
plt.xlim(15,30)
#plt.legend()
plt.title(str(len(qso_match_rows))+' qso of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_z-y_qso2.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_qso_lephare_notmatch,z_y_qso_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
plt.xlabel('g')
plt.ylabel('z-y')
plt.ylim(-1.5,1.5)
plt.xlim(15,30)
#plt.legend()
plt.title(str(len(qso_notmatch_lephare))+' qso of notmatch_lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_z-y_qso3.pdf')
plt.close()



#g vs g-y:
#galaxy:
plt.hist2d(MAG_AUTO_g_galaxy_match,g_y_galaxy_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.hist2d(MAG_AUTO_g_galaxy_lephare_notmatch,g_y_galaxy_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
plt.hist2d(MAG_AUTO_g_galaxy_true_notmatch,g_y_galaxy_true_notmatch,bins=30,norm=LogNorm(),cmap='Greens')
plt.xlabel('g')
plt.ylabel('g-y')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title('galaxy')
plt.text(15.1,3.5,'not_match _lephare: '+str(len(galaxy_notmatch_lephare))+'\n'+'not_match _true: '+str(len(galaxy_notmatch_true))+'\n'+'match: '+str(len(galaxy_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-y_galaxy.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_galaxy_match,g_y_galaxy_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.xlabel('g')
plt.ylabel('g-y')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(galaxy_match_rows))+' galaxy of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-y_galaxy1.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_galaxy_lephare_notmatch,g_y_galaxy_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
plt.xlabel('g')
plt.ylabel('g-y')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(galaxy_notmatch_lephare))+' galaxy of notmatch_lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-y_galaxy2.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_galaxy_true_notmatch,g_y_galaxy_true_notmatch,bins=30,norm=LogNorm(),cmap='Greens')
plt.xlabel('g')
plt.ylabel('g-y')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(galaxy_notmatch_true))+' galaxy of notmatch_true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-y_galaxy3.pdf')
plt.close()



#star:
plt.hist2d(MAG_AUTO_g_star_match,g_y_star_match,bins=80,norm=LogNorm(),cmap='Reds')#这个很奇怪，明明数量很大（1258），却只要80才能画好，300根本看不见。
plt.hist2d(MAG_AUTO_g_star_true_notmatch,g_y_star_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.hist2d(MAG_AUTO_g_star_lephare_notmatch,g_y_star_lephare_notmatch,bins=100,norm=LogNorm(),cmap='Blues')
plt.xlabel('g')
plt.ylabel('g-y')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title('star')
plt.text(15.1,3.5,'not_match _lephare: '+str(len(star_notmatch_lephare))+'\n'+'not_match _true: '+str(len(star_notmatch_true))+'\n'+'match: '+str(len(star_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-y_star.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_star_match,g_y_star_match,bins=80,norm=LogNorm(),cmap='Reds')#这个很奇怪，明明数量很大（1258），却只要80才能画好，300根本看不见。
plt.xlabel('g')
plt.ylabel('g-y')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(star_match_rows))+' star of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-y_star1.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_star_true_notmatch,g_y_star_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.xlabel('g')
plt.ylabel('g-y')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(star_notmatch_true))+' star of not_match _true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-y_star2.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_star_lephare_notmatch,g_y_star_lephare_notmatch,bins=100,norm=LogNorm(),cmap='Blues')
plt.xlabel('g')
plt.ylabel('g-y')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(star_notmatch_lephare))+' star of not_match _lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-y_star3.pdf')
plt.close()
'''

'''
#qso:
plt.hist2d(MAG_AUTO_g_qso_true_notmatch,g_y_qso_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.hist2d(MAG_AUTO_g_qso_match,g_y_qso_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.hist2d(MAG_AUTO_g_qso_lephare_notmatch,g_y_qso_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
plt.xlabel('g')
plt.ylabel('g-y')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title('qso')
plt.text(15.1,3.5,'not_match _lephare: '+str(len(qso_notmatch_lephare))+'\n'+'not_match _true: '+str(len(qso_notmatch_true))+'\n'+'match: '+str(len(qso_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-y_qso.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_qso_true_notmatch,g_y_qso_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.xlabel('g')
plt.ylabel('g-y')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(qso_notmatch_true))+' qso of not_match _true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-y_qso1.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_qso_match,g_y_qso_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.xlabel('g')
plt.ylabel('g-y')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(qso_match_rows))+' qso of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-y_qso2.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_qso_lephare_notmatch,g_y_qso_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
plt.xlabel('g')
plt.ylabel('g-y')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(qso_notmatch_lephare))+' qso of not_match _lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-y_qso3.pdf')
plt.close()






#g vs g-z:
#galaxy:
plt.hist2d(MAG_AUTO_g_galaxy_match,g_z_galaxy_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.hist2d(MAG_AUTO_g_galaxy_lephare_notmatch,g_z_galaxy_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
plt.hist2d(MAG_AUTO_g_galaxy_true_notmatch,g_z_galaxy_true_notmatch,bins=30,norm=LogNorm(),cmap='Greens')
plt.xlabel('g')
plt.ylabel('g-z')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title('galaxy')
plt.text(15.1,3.5,'not_match _lephare: '+str(len(galaxy_notmatch_lephare))+'\n'+'not_match _true: '+str(len(galaxy_notmatch_true))+'\n'+'match: '+str(len(galaxy_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-z_galaxy.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_galaxy_match,g_z_galaxy_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.xlabel('g')
plt.ylabel('g-z')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(galaxy_match_rows))+' galaxy of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-z_galaxy1.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_galaxy_lephare_notmatch,g_z_galaxy_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
plt.xlabel('g')
plt.ylabel('g-z')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(galaxy_notmatch_lephare))+' galaxy of notmatch_lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-z_galaxy2.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_galaxy_true_notmatch,g_z_galaxy_true_notmatch,bins=30,norm=LogNorm(),cmap='Greens')
plt.xlabel('g')
plt.ylabel('g-z')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(galaxy_notmatch_true))+' galaxy of notmatch_true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-z_galaxy3.pdf')
plt.close()



#star:
plt.hist2d(MAG_AUTO_g_star_match,g_z_star_match,bins=80,norm=LogNorm(),cmap='Reds')
plt.hist2d(MAG_AUTO_g_star_true_notmatch,g_z_star_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.hist2d(MAG_AUTO_g_star_lephare_notmatch,g_z_star_lephare_notmatch,bins=70,norm=LogNorm(),cmap='Blues')
plt.xlabel('g')
plt.ylabel('g-z')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title('star')
plt.text(15.1,3.5,'not_match _lephare: '+str(len(star_notmatch_lephare))+'\n'+'not_match _true: '+str(len(star_notmatch_true))+'\n'+'match: '+str(len(star_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-z_star.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_star_match,g_z_star_match,bins=80,norm=LogNorm(),cmap='Reds')
plt.xlabel('g')
plt.ylabel('g-z')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(star_match_rows))+' star of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-z_star1.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_star_true_notmatch,g_z_star_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.xlabel('g')
plt.ylabel('g-z')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(star_notmatch_true))+' star of not_match _true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-z_star2.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_star_lephare_notmatch,g_z_star_lephare_notmatch,bins=70,norm=LogNorm(),cmap='Blues')
plt.xlabel('g')
plt.ylabel('g-z')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(star_notmatch_lephare))+' star of not_match _lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-z_star3.pdf')
plt.close()




#qso:
plt.hist2d(MAG_AUTO_g_qso_true_notmatch,g_z_qso_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.hist2d(MAG_AUTO_g_qso_match,g_z_qso_match,bins=100,norm=LogNorm(),cmap='Reds')
plt.hist2d(MAG_AUTO_g_qso_lephare_notmatch,g_z_qso_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
#plt.colorbar(label='KIDS4('+str(len(z_ys3))+' qsos)')
plt.xlabel('g')
plt.ylabel('g-z')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title('qso')
plt.text(15.1,3.5,'not_match _lephare: '+str(len(qso_notmatch_lephare))+'\n'+'not_match _true: '+str(len(qso_notmatch_true))+'\n'+'match: '+str(len(qso_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-z_qso.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_qso_true_notmatch,g_z_qso_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.xlabel('g')
plt.ylabel('g-z')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(qso_notmatch_true))+' qso of not_match _true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-z_qso1.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_qso_match,g_z_qso_match,bins=100,norm=LogNorm(),cmap='Reds')
plt.xlabel('g')
plt.ylabel('g-z')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(qso_match_rows))+' qso of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-z_qso2.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_qso_lephare_notmatch,g_z_qso_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
plt.xlabel('g')
plt.ylabel('g-z')
plt.xlim(15,30)
plt.ylim(-1,5)
#plt.legend()
plt.title(str(len(qso_notmatch_lephare))+' qso of not_match _lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-z_qso3.pdf')
plt.close()




#r vs nuv-r:
#galaxy:
plt.hist2d(MAG_AUTO_r_galaxy_match,nuv_r_galaxy_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.hist2d(MAG_AUTO_r_galaxy_lephare_notmatch,nuv_r_galaxy_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
plt.hist2d(MAG_AUTO_r_galaxy_true_notmatch,nuv_r_galaxy_true_notmatch,bins=30,norm=LogNorm(),cmap='Greens')
plt.xlabel('r')
plt.ylabel('nuv-r')
plt.xlim(15,30)
plt.ylim(-3,6)
#plt.legend()
plt.title('galaxy')
plt.text(15.1,3.5,'not_match _lephare: '+str(len(galaxy_notmatch_lephare))+'\n'+'not_match _true: '+str(len(galaxy_notmatch_true))+'\n'+'match: '+str(len(galaxy_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-r_galaxy.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_galaxy_match,nuv_r_galaxy_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.xlabel('r')
plt.ylabel('nuv-r')
plt.xlim(15,30)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(galaxy_match_rows))+' galaxy of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-r_galaxy1.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_galaxy_lephare_notmatch,nuv_r_galaxy_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
plt.xlabel('r')
plt.ylabel('nuv-r')
plt.xlim(15,30)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(galaxy_notmatch_lephare))+' galaxy of notmatch_lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-r_galaxy2.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_galaxy_true_notmatch,nuv_r_galaxy_true_notmatch,bins=30,norm=LogNorm(),cmap='Greens')
plt.xlabel('r')
plt.ylabel('nuv-r')
plt.xlim(15,30)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(galaxy_notmatch_true))+' galaxy of notmatch_true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-r_galaxy3.pdf')
plt.close()



#star:
plt.hist2d(MAG_AUTO_r_star_match,nuv_r_star_match,bins=80,norm=LogNorm(),cmap='Reds')
plt.hist2d(MAG_AUTO_r_star_true_notmatch,nuv_r_star_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.hist2d(MAG_AUTO_r_star_lephare_notmatch,nuv_r_star_lephare_notmatch,bins=70,norm=LogNorm(),cmap='Blues')
plt.xlabel('r')
plt.ylabel('nuv-r')
plt.xlim(15,30)
plt.ylim(-3,6)
#plt.legend()
plt.title('star')
plt.text(15.1,3.5,'not_match _lephare: '+str(len(star_notmatch_lephare))+'\n'+'not_match _true: '+str(len(star_notmatch_true))+'\n'+'match: '+str(len(star_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-r_star.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_star_match,nuv_r_star_match,bins=80,norm=LogNorm(),cmap='Reds')
plt.xlabel('r')
plt.ylabel('nuv-r')
plt.xlim(15,30)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(star_match_rows))+' star of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-r_star1.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_star_true_notmatch,nuv_r_star_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.xlabel('r')
plt.ylabel('nuv-r')
plt.xlim(15,30)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(star_notmatch_true))+' star of not_match _true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-r_star2.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_star_lephare_notmatch,nuv_r_star_lephare_notmatch,bins=70,norm=LogNorm(),cmap='Blues')
plt.xlabel('r')
plt.ylabel('nuv-r')
plt.xlim(15,30)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(star_notmatch_lephare))+' star of not_match _lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-r_star3.pdf')
plt.close()




#qso:
plt.hist2d(MAG_AUTO_r_qso_true_notmatch,nuv_r_qso_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.hist2d(MAG_AUTO_r_qso_match,nuv_r_qso_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.hist2d(MAG_AUTO_r_qso_lephare_notmatch,nuv_r_qso_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
#plt.colorbar(label='KIDS4('+str(len(z_ys3))+' qsos)')
plt.xlabel('r')
plt.ylabel('nuv-r')
plt.xlim(15,30)
plt.ylim(-3,6)
#plt.legend()
plt.title('qso')
plt.text(15.1,3.5,'not_match _lephare: '+str(len(qso_notmatch_lephare))+'\n'+'not_match _true: '+str(len(qso_notmatch_true))+'\n'+'match: '+str(len(qso_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-r_qso.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_qso_true_notmatch,nuv_r_qso_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.xlabel('r')
plt.ylabel('nuv-r')
plt.xlim(15,30)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(qso_notmatch_true))+' qso of not_match _true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-r_qso1.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_qso_match,nuv_r_qso_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.xlabel('r')
plt.ylabel('nuv-r')
plt.xlim(15,30)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(qso_notmatch_lephare))+' qso of not_match _lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-r_qso2.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_qso_lephare_notmatch,nuv_r_qso_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
plt.xlabel('r')
plt.ylabel('nuv-r')
plt.xlim(15,30)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(qso_match_rows))+' qso of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-r_qso3.pdf')
plt.close()



#nuv_r vs z_y:
#galaxy:
plt.hist2d(z_y_galaxy_match,nuv_r_galaxy_match,bins=300,norm=LogNorm(),cmap='Reds',alpha=1)
plt.hist2d(z_y_galaxy_true_notmatch,nuv_r_galaxy_true_notmatch,bins=30,norm=LogNorm(),cmap='Greens')
plt.hist2d(z_y_galaxy_lephare_notmatch,nuv_r_galaxy_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues',alpha=1)
#plt.scatter(z_y_galaxy_lephare_notmatch,nuv_r_galaxy_lephare_notmatch)
#plt.colorbar(label='Count')
plt.ylabel('nuv-r')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,6)
#plt.legend()
plt.title('galaxy')
plt.text(-1.4,3.5,'not_match _lephare: '+str(len(galaxy_notmatch_lephare))+'\n'+'not_match _true: '+str(len(galaxy_notmatch_true))+'\n'+'match: '+str(len(galaxy_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-r_z-y_galaxy.pdf')
plt.close()

plt.hist2d(z_y_galaxy_lephare_notmatch,nuv_r_galaxy_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
#plt.colorbar(label='Count')
plt.ylabel('nuv-r')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(galaxy_notmatch_lephare))+' galaxies of not_match _lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-r_z-y_galaxy1.pdf')
plt.close()

plt.hist2d(z_y_galaxy_true_notmatch,nuv_r_galaxy_true_notmatch,bins=30,norm=LogNorm(),cmap='Greens')
plt.ylabel('nuv-r')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(galaxy_notmatch_true))+' galaxies of not_match _true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-r_z-y_galaxy2.pdf')
plt.close()


plt.hist2d(z_y_galaxy_match,nuv_r_galaxy_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.ylabel('nuv-r')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(galaxy_match_rows))+' galaxies of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-r_z-y_galaxy3.pdf')
plt.close()




#star:
plt.hist2d(z_y_star_match,nuv_r_star_match,bins=80,norm=LogNorm(),cmap='Reds')
plt.hist2d(z_y_star_true_notmatch,nuv_r_star_true_notmatch,bins=600,norm=LogNorm(),cmap='Greens')
plt.hist2d(z_y_star_lephare_notmatch,nuv_r_star_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
#plt.colorbar(label='KIDS4('+str(len(z_ys2))+' stars)')
plt.ylabel('nuv-r')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,6)
#plt.legend()
plt.title('star')
plt.text(-1.3,3,'not_match _lephare: '+str(len(star_notmatch_lephare))+'\n'+'not_match _true: '+str(len(star_notmatch_true))+'\n'+'match: '+str(len(star_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-r_z-y_star.pdf')
plt.close()

plt.hist2d(z_y_star_match,nuv_r_star_match,bins=80,norm=LogNorm(),cmap='Reds')
plt.ylabel('nuv-r')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(star_match_rows))+' stars of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-r_z-y_star1.pdf')
plt.close()

plt.hist2d(z_y_star_true_notmatch,nuv_r_star_true_notmatch,bins=600,norm=LogNorm(),cmap='Greens')
plt.ylabel('nuv-r')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(star_notmatch_true))+' stars of not_match _true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-r_z-y_star2.pdf')
plt.close()


plt.hist2d(z_y_star_lephare_notmatch,nuv_r_star_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
#plt.colorbar(label='Count')
plt.ylabel('nuv-r')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(star_notmatch_lephare))+' stars of not_match _lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-r_z-y_star3.pdf')
plt.close()





#qso:
plt.hist2d(z_y_qso_true_notmatch,nuv_r_qso_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.hist2d(z_y_qso_match,nuv_r_qso_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.hist2d(z_y_qso_lephare_notmatch,nuv_r_qso_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
plt.ylabel('nuv-r')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,6)
#plt.legend()
plt.title('qso')
plt.text(-1.4,-2.8,'not_match _lephare: '+str(len(qso_notmatch_lephare))+'\n'+'not_match _true: '+str(len(qso_notmatch_true))+'\n'+'match: '+str(len(qso_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-r_z-y_qso.pdf')
plt.close()


plt.hist2d(z_y_qso_true_notmatch,nuv_r_qso_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.ylabel('nuv-r')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(qso_notmatch_true))+' qsos of not_match _true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-r_z-y_qso1.pdf')
plt.close()


plt.hist2d(z_y_qso_lephare_notmatch,nuv_r_qso_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
#plt.colorbar(label='KIDS4('+str(len(z_ys3))+' qsos)')
plt.ylabel('nuv-r')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(qso_notmatch_lephare))+' qsos of not_match _lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-r_z-y_qso2.pdf')
plt.close()


plt.hist2d(z_y_qso_match,nuv_r_qso_match,bins=300,norm=LogNorm(),cmap='Reds')
#plt.colorbar(label='KIDS4('+str(len(z_ys3))+' qsos)')
plt.ylabel('nuv-r')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(qso_match_rows))+' qsos of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-r_z-y_qso3.pdf')
plt.close()



#r vs nuv-u:
#galaxy:
plt.hist2d(MAG_AUTO_r_galaxy_match,nuv_u_galaxy_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.hist2d(MAG_AUTO_r_galaxy_lephare_notmatch,nuv_u_galaxy_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
plt.hist2d(MAG_AUTO_r_galaxy_true_notmatch,nuv_u_galaxy_true_notmatch,bins=30,norm=LogNorm(),cmap='Greens')
plt.xlabel('r')
plt.ylabel('nuv-u')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title('galaxy')
plt.text(15.1,3.5,'not_match _lephare: '+str(len(galaxy_notmatch_lephare))+'\n'+'not_match _true: '+str(len(galaxy_notmatch_true))+'\n'+'match: '+str(len(galaxy_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-u_galaxy.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_galaxy_match,nuv_u_galaxy_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.xlabel('r')
plt.ylabel('nuv-u')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(galaxy_match_rows))+' galaxy of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-u_galaxy1.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_galaxy_lephare_notmatch,nuv_u_galaxy_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
plt.xlabel('r')
plt.ylabel('nuv-u')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(galaxy_notmatch_lephare))+' galaxy of notmatch_lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-u_galaxy2.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_galaxy_true_notmatch,nuv_u_galaxy_true_notmatch,bins=30,norm=LogNorm(),cmap='Greens')
plt.xlabel('r')
plt.ylabel('nuv-u')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(galaxy_notmatch_true))+' galaxy of notmatch_true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-u_galaxy3.pdf')
plt.close()



#star:
plt.hist2d(MAG_AUTO_r_star_match,nuv_u_star_match,bins=80,norm=LogNorm(),cmap='Reds')
plt.hist2d(MAG_AUTO_r_star_true_notmatch,nuv_u_star_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.hist2d(MAG_AUTO_r_star_lephare_notmatch,nuv_u_star_lephare_notmatch,bins=70,norm=LogNorm(),cmap='Blues')
plt.xlabel('r')
plt.ylabel('nuv-u')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title('star')
plt.text(15.1,3.5,'not_match _lephare: '+str(len(star_notmatch_lephare))+'\n'+'not_match _true: '+str(len(star_notmatch_true))+'\n'+'match: '+str(len(star_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-u_star.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_star_match,nuv_u_star_match,bins=80,norm=LogNorm(),cmap='Reds')
plt.xlabel('r')
plt.ylabel('nuv-u')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(star_match_rows))+' star of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-u_star1.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_star_true_notmatch,nuv_u_star_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.xlabel('r')
plt.ylabel('nuv-u')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(star_notmatch_true))+' star of not_match _true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-u_star2.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_star_lephare_notmatch,nuv_u_star_lephare_notmatch,bins=70,norm=LogNorm(),cmap='Blues')
plt.xlabel('r')
plt.ylabel('nuv-u')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(star_notmatch_lephare))+' star of not_match _lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-u_star3.pdf')
plt.close()




#qso:
plt.hist2d(MAG_AUTO_r_qso_true_notmatch,nuv_u_qso_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.hist2d(MAG_AUTO_r_qso_match,nuv_u_qso_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.hist2d(MAG_AUTO_r_qso_lephare_notmatch,nuv_u_qso_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
#plt.colorbar(label='KIDS4('+str(len(z_ys3))+' qsos)')
plt.xlabel('r')
plt.ylabel('nuv-u')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title('qso')
plt.text(15.1,3.5,'not_match _lephare: '+str(len(qso_notmatch_lephare))+'\n'+'not_match _true: '+str(len(qso_notmatch_true))+'\n'+'match: '+str(len(qso_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-u_qso.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_qso_true_notmatch,nuv_u_qso_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.xlabel('r')
plt.ylabel('nuv-u')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(qso_notmatch_true))+' qso of not_match _true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-u_qso1.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_qso_match,nuv_u_qso_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.xlabel('r')
plt.ylabel('nuv-u')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(qso_notmatch_lephare))+' qso of not_match _lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-u_qso2.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_qso_lephare_notmatch,nuv_u_qso_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
plt.xlabel('r')
plt.ylabel('nuv-u')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(qso_match_rows))+' qso of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-u_qso3.pdf')
plt.close()





#nuv_g vs z_y:
#galaxy:
plt.hist2d(z_y_galaxy_match,nuv_g_galaxy_match,bins=300,norm=LogNorm(),cmap='Reds',alpha=1)
plt.hist2d(z_y_galaxy_true_notmatch,nuv_g_galaxy_true_notmatch,bins=30,norm=LogNorm(),cmap='Greens')
plt.hist2d(z_y_galaxy_lephare_notmatch,nuv_g_galaxy_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues',alpha=1)
#plt.scatter(z_y_galaxy_lephare_notmatch,nuv_g_galaxy_lephare_notmatch)
#plt.colorbar(label='Count')
plt.ylabel('nuv-g')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-4,6)
#plt.legend()
plt.title('galaxy')
plt.text(-1.4,3.5,'not_match _lephare: '+str(len(galaxy_notmatch_lephare))+'\n'+'not_match _true: '+str(len(galaxy_notmatch_true))+'\n'+'match: '+str(len(galaxy_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-g_z-y_galaxy.pdf')
plt.close()

plt.hist2d(z_y_galaxy_lephare_notmatch,nuv_g_galaxy_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
#plt.colorbar(label='Count')
plt.ylabel('nuv-g')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(galaxy_notmatch_lephare))+' galaxies of not_match _lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-g_z-y_galaxy1.pdf')
plt.close()

plt.hist2d(z_y_galaxy_true_notmatch,nuv_g_galaxy_true_notmatch,bins=30,norm=LogNorm(),cmap='Greens')
plt.ylabel('nuv-g')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(galaxy_notmatch_true))+' galaxies of not_match _true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-g_z-y_galaxy2.pdf')
plt.close()


plt.hist2d(z_y_galaxy_match,nuv_g_galaxy_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.ylabel('nuv-g')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(galaxy_match_rows))+' galaxies of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-g_z-y_galaxy3.pdf')
plt.close()




#star:
plt.hist2d(z_y_star_match,nuv_g_star_match,bins=80,norm=LogNorm(),cmap='Reds')
plt.hist2d(z_y_star_true_notmatch,nuv_g_star_true_notmatch,bins=600,norm=LogNorm(),cmap='Greens')
plt.hist2d(z_y_star_lephare_notmatch,nuv_g_star_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
#plt.colorbar(label='KIDS4('+str(len(z_ys2))+' stars)')
plt.ylabel('nuv-g')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-4,6)
#plt.legend()
plt.title('star')
plt.text(-1.3,3,'not_match _lephare: '+str(len(star_notmatch_lephare))+'\n'+'not_match _true: '+str(len(star_notmatch_true))+'\n'+'match: '+str(len(star_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-g_z-y_star.pdf')
plt.close()

plt.hist2d(z_y_star_match,nuv_g_star_match,bins=80,norm=LogNorm(),cmap='Reds')
plt.ylabel('nuv-g')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(star_match_rows))+' stars of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-g_z-y_star1.pdf')
plt.close()

plt.hist2d(z_y_star_true_notmatch,nuv_g_star_true_notmatch,bins=600,norm=LogNorm(),cmap='Greens')
plt.ylabel('nuv-g')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(star_notmatch_true))+' stars of not_match _true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-g_z-y_star2.pdf')
plt.close()


plt.hist2d(z_y_star_lephare_notmatch,nuv_g_star_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
#plt.colorbar(label='Count')
plt.ylabel('nuv-g')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(star_notmatch_lephare))+' stars of not_match _lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-g_z-y_star3.pdf')
plt.close()





#qso:
plt.hist2d(z_y_qso_true_notmatch,nuv_g_qso_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.hist2d(z_y_qso_match,nuv_g_qso_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.hist2d(z_y_qso_lephare_notmatch,nuv_g_qso_lephare_notmatch,bins=600,norm=LogNorm(),cmap='Blues')
plt.ylabel('nuv-g')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-4,6)
#plt.legend()
plt.title('qso')
plt.text(-1.4,-2.8,'not_match _lephare: '+str(len(qso_notmatch_lephare))+'\n'+'not_match _true: '+str(len(qso_notmatch_true))+'\n'+'match: '+str(len(qso_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-g_z-y_qso.pdf')
plt.close()


plt.hist2d(z_y_qso_true_notmatch,nuv_g_qso_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.ylabel('nuv-g')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(qso_notmatch_true))+' qsos of not_match _true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-g_z-y_qso1.pdf')
plt.close()


plt.hist2d(z_y_qso_lephare_notmatch,nuv_g_qso_lephare_notmatch,bins=600,norm=LogNorm(),cmap='Blues')
#plt.colorbar(label='KIDS4('+str(len(z_ys3))+' qsos)')
plt.ylabel('nuv-g')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(qso_notmatch_lephare))+' qsos of not_match _lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-g_z-y_qso2.pdf')
plt.close()


plt.hist2d(z_y_qso_match,nuv_g_qso_match,bins=300,norm=LogNorm(),cmap='Reds')
#plt.colorbar(label='KIDS4('+str(len(z_ys3))+' qsos)')
plt.ylabel('nuv-g')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(qso_match_rows))+' qsos of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-g_z-y_qso3.pdf')
plt.close()





#y vs nuv-g:
#galaxy:
plt.hist2d(MAG_AUTO_y_galaxy_match,nuv_g_galaxy_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.hist2d(MAG_AUTO_y_galaxy_lephare_notmatch,nuv_g_galaxy_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
plt.hist2d(MAG_AUTO_y_galaxy_true_notmatch,nuv_g_galaxy_true_notmatch,bins=30,norm=LogNorm(),cmap='Greens')
plt.xlabel('y')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,6)
#plt.legend()
plt.title('galaxy')
plt.text(15.1,3.5,'not_match _lephare: '+str(len(galaxy_notmatch_lephare))+'\n'+'not_match _true: '+str(len(galaxy_notmatch_true))+'\n'+'match: '+str(len(galaxy_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/y_nuv-g_galaxy.pdf')
plt.close()

plt.hist2d(MAG_AUTO_y_galaxy_match,nuv_g_galaxy_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.xlabel('y')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(galaxy_match_rows))+' galaxy of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/y_nuv-g_galaxy1.pdf')
plt.close()

plt.hist2d(MAG_AUTO_y_galaxy_lephare_notmatch,nuv_g_galaxy_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
plt.xlabel('y')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(galaxy_notmatch_lephare))+' galaxy of notmatch_lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/y_nuv-g_galaxy2.pdf')
plt.close()

plt.hist2d(MAG_AUTO_y_galaxy_true_notmatch,nuv_g_galaxy_true_notmatch,bins=30,norm=LogNorm(),cmap='Greens')
plt.xlabel('y')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(galaxy_notmatch_true))+' galaxy of notmatch_true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/y_nuv-g_galaxy3.pdf')
plt.close()



#star:
plt.hist2d(MAG_AUTO_y_star_match,nuv_g_star_match,bins=80,norm=LogNorm(),cmap='Reds')
plt.hist2d(MAG_AUTO_y_star_true_notmatch,nuv_g_star_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.hist2d(MAG_AUTO_y_star_lephare_notmatch,nuv_g_star_lephare_notmatch,bins=70,norm=LogNorm(),cmap='Blues')
plt.xlabel('y')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,6)
#plt.legend()
plt.title('star')
plt.text(15.1,3.5,'not_match _lephare: '+str(len(star_notmatch_lephare))+'\n'+'not_match _true: '+str(len(star_notmatch_true))+'\n'+'match: '+str(len(star_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/y_nuv-g_star.pdf')
plt.close()

plt.hist2d(MAG_AUTO_y_star_match,nuv_g_star_match,bins=80,norm=LogNorm(),cmap='Reds')
plt.xlabel('y')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(star_match_rows))+' star of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/y_nuv-g_star1.pdf')
plt.close()

plt.hist2d(MAG_AUTO_y_star_true_notmatch,nuv_g_star_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.xlabel('y')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(star_notmatch_true))+' star of not_match _true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/y_nuv-g_star2.pdf')
plt.close()

plt.hist2d(MAG_AUTO_y_star_lephare_notmatch,nuv_g_star_lephare_notmatch,bins=70,norm=LogNorm(),cmap='Blues')
plt.xlabel('y')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(star_notmatch_lephare))+' star of not_match _lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/y_nuv-g_star3.pdf')
plt.close()




#qso:
plt.hist2d(MAG_AUTO_y_qso_true_notmatch,nuv_g_qso_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.hist2d(MAG_AUTO_y_qso_match,nuv_g_qso_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.hist2d(MAG_AUTO_y_qso_lephare_notmatch,nuv_g_qso_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
#plt.colorbar(label='KIDS4('+str(len(z_ys3))+' qsos)')
plt.xlabel('y')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,6)
#plt.legend()
plt.title('qso')
plt.text(15.1,3.5,'not_match _lephare: '+str(len(qso_notmatch_lephare))+'\n'+'not_match _true: '+str(len(qso_notmatch_true))+'\n'+'match: '+str(len(qso_match_rows)),fontdict={'size': 10, 'color': 'k'})
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/y_nuv-g_qso.pdf')
plt.close()

plt.hist2d(MAG_AUTO_y_qso_true_notmatch,nuv_g_qso_true_notmatch,bins=300,norm=LogNorm(),cmap='Greens')
plt.xlabel('y')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(qso_notmatch_true))+' qso of not_match _true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/y_nuv-g_qso1.pdf')
plt.close()

plt.hist2d(MAG_AUTO_y_qso_match,nuv_g_qso_match,bins=300,norm=LogNorm(),cmap='Reds')
plt.xlabel('y')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(qso_notmatch_lephare))+' qso of not_match _lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/y_nuv-g_qso2.pdf')
plt.close()

plt.hist2d(MAG_AUTO_y_qso_lephare_notmatch,nuv_g_qso_lephare_notmatch,bins=300,norm=LogNorm(),cmap='Blues')
plt.xlabel('y')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(qso_match_rows))+' qso of match')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/y_nuv-g_qso3.pdf')
plt.close()



#true 图：
#nuv-g vs z-y:
plt.hist2d(z_y_galaxy_true,nuv_g_galaxy_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.ylabel('nuv-g')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(rows_galaxy_true))+' galaxies of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-g_z-y_galaxy_true.pdf')
plt.close()


plt.hist2d(z_y_star_true,nuv_g_star_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.ylabel('nuv-g')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-4,5)
plt.title(str(len(rows_star_true))+' stars of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-g_z-y_star_true.pdf')
plt.close()



plt.hist2d(z_y_qso_true,nuv_g_qso_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.ylabel('nuv-g')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-4,5)
plt.title(str(len(rows_qso_true))+' qsos of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-g_z-y_qso_true.pdf')
plt.close()





#g vs nuv-g:
plt.hist2d(MAG_AUTO_g_galaxy_true,nuv_g_galaxy_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('g')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(rows_galaxy_true))+' galaxies of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_nuv-g_galaxy_true.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_star_true,nuv_g_star_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('g')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(rows_star_true))+' stars of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_nuv-g_star_true.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_qso_true,nuv_g_qso_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('g')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(rows_qso_true))+' qsos of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_nuv-g_qso_true.pdf')
plt.close()


#g vs g-y:
plt.hist2d(MAG_AUTO_g_galaxy_true,g_y_galaxy_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('g')
plt.ylabel('g-y')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(rows_galaxy_true))+' galaxies of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-y_galaxy_true.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_star_true,g_y_star_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('g')
plt.ylabel('g-y')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(rows_star_true))+' stars of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-y_star_true.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_qso_true,g_y_qso_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('g')
plt.ylabel('g-y')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(rows_qso_true))+' qsos of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-y_qso_true.pdf')
plt.close()



#y vs nuv-g:
plt.hist2d(MAG_AUTO_y_galaxy_true,nuv_g_galaxy_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('y')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(rows_galaxy_true))+' galaxies of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/y_nuv-g_galaxy_true.pdf')
plt.close()

plt.hist2d(MAG_AUTO_y_star_true,nuv_g_star_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('y')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(rows_star_true))+' stars of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/y_nuv-g_star_true.pdf')
plt.close()

plt.hist2d(MAG_AUTO_y_qso_true,nuv_g_qso_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('y')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(rows_qso_true))+' qsos of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/y_nuv-g_qso_true.pdf')
plt.close()





#r vs nuv-u:
plt.hist2d(MAG_AUTO_r_galaxy_true,nuv_u_galaxy_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('r')
plt.ylabel('nuv-u')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(rows_galaxy_true))+' galaxies of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-u_galaxy_true.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_star_true,nuv_u_star_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('r')
plt.ylabel('nuv-u')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(rows_star_true))+' stars of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-u_star_true.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_qso_true,nuv_u_qso_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('r')
plt.ylabel('nuv-u')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(rows_qso_true))+' qsos of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-u_qso_true.pdf')
plt.close()


#r vs nuv_r:
plt.hist2d(MAG_AUTO_r_galaxy_true,nuv_r_galaxy_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('r')
plt.ylabel('nuv_r')
plt.xlim(15,30)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(rows_galaxy_true))+' galaxies of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv_r_galaxy_true.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_star_true,nuv_r_star_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('r')
plt.ylabel('nuv_r')
plt.xlim(15,30)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(rows_star_true))+' stars of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv_r_star_true.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_qso_true,nuv_r_qso_true,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('r')
plt.ylabel('nuv_r')
plt.xlim(15,30)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(rows_qso_true))+' qsos of true')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv_r_qso_true.pdf')
plt.close()
'''


'''
#lephare 图：
#nuv-g vs z-y:
plt.hist2d(z_y_galaxy_lephare,nuv_g_galaxy_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.ylabel('nuv-g')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(GAL_rows))+' galaxies of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-g_z-y_galaxy_lephare.pdf')
plt.close()


plt.hist2d(z_y_star_lephare,nuv_g_star_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.ylabel('nuv-g')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-4,5)
plt.title(str(len(STAR_rows))+' stars of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-g_z-y_star_lephare.pdf')
plt.close()



plt.hist2d(z_y_qso_lephare,nuv_g_qso_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.ylabel('nuv-g')
plt.xlabel('z-y')
plt.xlim(-1.5,1.5)
plt.ylim(-4,5)
plt.title(str(len(QSO_rows))+' qsos of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/nuv-g_z-y_qso_lephare.pdf')
plt.close()
'''



'''
#g vs nuv-g:
plt.hist2d(MAG_AUTO_g_galaxy_lephare,nuv_g_galaxy_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('g')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(GAL_rows))+' galaxies of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_nuv-g_galaxy_lephare.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_star_lephare,nuv_g_star_lephare,bins=100,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('g')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(STAR_rows))+' stars of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_nuv-g_star_lephare.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_qso_lephare,nuv_g_qso_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('g')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(QSO_rows))+' qsos of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_nuv-g_qso_lephare.pdf')
plt.close()

#g vs g-y:
plt.hist2d(MAG_AUTO_g_galaxy_lephare,g_y_galaxy_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('g')
plt.ylabel('g-y')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(GAL_rows))+' galaxies of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-y_galaxy_lephare.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_star_lephare,g_y_star_lephare,bins=100,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('g')
plt.ylabel('g-y')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(STAR_rows))+' stars of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-y_star_lephare.pdf')
plt.close()

plt.hist2d(MAG_AUTO_g_qso_lephare,g_y_qso_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('g')
plt.ylabel('g-y')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(QSO_rows))+' qsos of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/g_g-y_qso_lephare.pdf')
plt.close()


#y vs nuv-g:
plt.hist2d(MAG_AUTO_y_galaxy_lephare,nuv_g_galaxy_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('y')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(GAL_rows))+' galaxies of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/y_nuv-g_galaxy_lephare.pdf')
plt.close()

plt.hist2d(MAG_AUTO_y_star_lephare,nuv_g_star_lephare,bins=100,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('y')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(STAR_rows))+' stars of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/y_nuv-g_star_lephare.pdf')
plt.close()

plt.hist2d(MAG_AUTO_y_qso_lephare,nuv_g_qso_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('y')
plt.ylabel('nuv-g')
plt.xlim(15,30)
plt.ylim(-4,6)
#plt.legend()
plt.title(str(len(QSO_rows))+' qsos of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/y_nuv-g_qso_lephare.pdf')
plt.close()





#r vs nuv-u:
plt.hist2d(MAG_AUTO_r_galaxy_lephare,nuv_u_galaxy_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('r')
plt.ylabel('nuv-u')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(GAL_rows))+' galaxies of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-u_galaxy_lephare.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_star_lephare,nuv_u_star_lephare,bins=100,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('r')
plt.ylabel('nuv-u')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(STAR_rows))+' stars of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-u_star_lephare.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_qso_lephare,nuv_u_qso_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('r')
plt.ylabel('nuv-u')
plt.xlim(15,30)
plt.ylim(-4,5)
#plt.legend()
plt.title(str(len(QSO_rows))+' qsos of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv-u_qso_lephare.pdf')
plt.close()


#r vs nuv_r:
plt.hist2d(MAG_AUTO_r_galaxy_lephare,nuv_r_galaxy_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('r')
plt.ylabel('nuv_r')
plt.xlim(15,30)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(GAL_rows))+' galaxies of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv_r_galaxy_lephare.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_star_lephare,nuv_r_star_lephare,bins=100,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('r')
plt.ylabel('nuv_r')
plt.xlim(15,30)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(STAR_rows))+' stars of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv_r_star_lephare.pdf')
plt.close()

plt.hist2d(MAG_AUTO_r_qso_lephare,nuv_r_qso_lephare,bins=300,norm=LogNorm(),cmap='RdYlBu')
plt.xlabel('r')
plt.ylabel('nuv_r')
plt.xlim(15,30)
plt.ylim(-3,6)
#plt.legend()
plt.title(str(len(QSO_rows))+' qsos of lephare')
plt.savefig('/media/xie/C022AA4B225A6D42/job/CSST/mock_catalog1/result/z_v3_x/r_nuv_r_qso_lephare.pdf')
plt.close()
'''


endtime = datetime.datetime.now()
usetime=endtime - starttime
print ('plot time use: %s'%(usetime))




